import SwiftUI

struct HomeView: View {
    var body: some View {
        NavigationStack {
            ZStack {
                // Background Gradient
                LinearGradient(
                    gradient: Gradient(colors: [Color.blue.opacity(0.7), .white]),
                    startPoint: .top,
                    endPoint: .bottom
                )
                .ignoresSafeArea()

                VStack(spacing: 25) { // Increased spacing between texts
                    
                    // Logo Image (Top)
                    Image("mainLogo") // Ensure image is in Assets
                        .resizable()
                        .scaledToFit()
                        .frame(width: 100, height: 100)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .shadow(color: .black.opacity(0.2), radius: 10, y: 4)
                        .padding(.top, 30)

                    // App Title
                    Text("BookMyHall")
                        .font(.custom("Roboto", size: 36))
                        .fontWeight(.semibold)
                        .foregroundColor(.black)

                    // Subtitle
                    Text("Explore Your Venues Here")
                        .font(.custom("Roboto", size: 22))
                        .fontWeight(.medium)
                        .foregroundColor(.gray)

                    // Description Text
                    Text("Your Perfect Venue Awaits")
                        .font(.custom("Roboto", size: 16))
                        .fontWeight(.medium)
                        .foregroundColor(.gray)

                    Spacer().frame(height: 40) // Spacing before button

                    // Navigation Button
                    NavigationLink(destination: LoginView(showTabBar: .constant(true)).navigationBarBackButtonHidden(true)) {
                        Text("Let’s Get Started")
                            .font(.custom("Roboto", size: 18))
                            .fontWeight(.medium)
                            .foregroundColor(.white)
                            .frame(width: 280, height: 50)
                            .background(Color.black)
                            .cornerRadius(8)
                            .shadow(color: Color.black.opacity(0.4), radius: 10, y: 4)
                    }
                    .padding(.top, 20)
                }
                .frame(width: 350) // Centered Content
            }
        }
        .navigationViewStyle(StackNavigationViewStyle())
    }
}

// Preview
struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
