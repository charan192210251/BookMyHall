import SwiftUI

struct UploadImagesView: View {
    @Environment(\.presentationMode) var presentationMode
    let hallID: String

    @State private var selectedImages: [UIImage] = []
    @State private var isPickerPresented = false
    @State private var isLoading = false
    @State private var uploadSuccess = false
    @State private var errorMessage = ""
    @State private var showAlert = false // State for alert popup

    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.7), .white]),
                           startPoint: .top, endPoint: .bottom)
            .edgesIgnoringSafeArea(.all)

            VStack(spacing: 20) {
                HStack {
                    Button(action: { presentationMode.wrappedValue.dismiss() }) {
                        Image(systemName: "chevron.left")
                            .font(.system(size: 20, weight: .bold))
                            .foregroundColor(.black)
                            .padding()
                    }
                    .offset(y:-250)
                    Spacer()
                }
                .padding(.top, 20)

                if !selectedImages.isEmpty {
                    ScrollView(.horizontal) {
                        HStack(spacing: 15) {
                            ForEach(selectedImages, id: \.self) { image in
                                Image(uiImage: image)
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width: 100, height: 100)
                                    .clipShape(RoundedRectangle(cornerRadius: 15))
                            }
                        }
                        .padding()
                    }
                }

                Button(action: { isPickerPresented.toggle(); errorMessage = "" }) {
                    Text("Select Images")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(15)
                        .shadow(radius: 4)
                }
                .padding(.horizontal)

                Button(action: {
                    if selectedImages.isEmpty {
                        errorMessage = "Please select at least one image before uploading."
                        showAlert = true
                    } else {
                        uploadImages()
                    }
                }) {
                    Text("Upload Images")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(selectedImages.isEmpty ? Color.gray : Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(15)
                        .shadow(radius: 4)
                }
                .padding(.horizontal)
                .disabled(selectedImages.isEmpty)

                if isLoading { ProgressView("Uploading...").padding() }
            }
            .padding()
        }
        .sheet(isPresented: $isPickerPresented) {
            PhotoPicker(selectedImages: $selectedImages)
        }
        .alert(isPresented: $showAlert) {
            Alert(
                title: Text(uploadSuccess ? "Success" : "Error"),
                message: Text(uploadSuccess ? "Images uploaded successfully!" : errorMessage),
                dismissButton: .default(Text("OK")) {
                    if uploadSuccess {
                        selectedImages.removeAll() // Clear images after success
                    }
                }
            )
        }
    }

    func uploadImages() {
        guard !selectedImages.isEmpty else { return }
        isLoading = true
        uploadSuccess = false
        errorMessage = ""

        let url = URL(string: "http://localhost/BookMyHall/uploadImages.php")!

        for (index, image) in selectedImages.enumerated() {
            var request = URLRequest(url: url)
            request.httpMethod = "POST"

            let boundary = UUID().uuidString
            request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")

            var body = Data()

            // Add hall_id to the request body
            body.append("--\(boundary)\r\n".data(using: .utf8)!)
            body.append("Content-Disposition: form-data; name=\"hall_id\"\r\n\r\n".data(using: .utf8)!)
            body.append("\(hallID)\r\n".data(using: .utf8)!)

            // Upload each image separately as "image"
            guard let imageData = image.jpegData(compressionQuality: 0.8) else { continue }
            let filename = "image\(index + 1).jpg"

            body.append("--\(boundary)\r\n".data(using: .utf8)!)
            body.append("Content-Disposition: form-data; name=\"image\"; filename=\"\(filename)\"\r\n".data(using: .utf8)!)
            body.append("Content-Type: image/jpeg\r\n\r\n".data(using: .utf8)!)
            body.append(imageData)
            body.append("\r\n".data(using: .utf8)!)

            body.append("--\(boundary)--\r\n".data(using: .utf8)!)
            request.httpBody = body

            // Send request
            URLSession.shared.dataTask(with: request) { data, response, error in
                DispatchQueue.main.async {
                    self.isLoading = false
                    if let error = error {
                        self.errorMessage = "Upload failed: \(error.localizedDescription)"
                        self.showAlert = true
                        return
                    }
                    guard let data = data else {
                        self.errorMessage = "No response from server"
                        self.showAlert = true
                        return
                    }
                    do {
                        if let jsonResponse = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] {
                            if let success = jsonResponse["success"] as? Bool, success {
                                self.uploadSuccess = true
                                self.showAlert = true
                            } else {
                                self.errorMessage = jsonResponse["message"] as? String ?? "Upload failed"
                                self.showAlert = true
                            }
                        } else {
                            self.errorMessage = "Invalid server response"
                            self.showAlert = true
                        }
                    } catch {
                        self.errorMessage = "Error parsing response: \(error.localizedDescription)"
                        self.showAlert = true
                    }
                }
            }.resume()
        }
    }
}

struct UploadImagesView_Previews: PreviewProvider {
    static var previews: some View {
        UploadImagesView(hallID: "1") // Sample hall ID for preview
    }
}
