import SwiftUI
import MessageUI

struct ContactUsView: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var name = UserDefaults.standard.string(forKey: "name") ?? ""
    @State private var email = UserDefaults.standard.string(forKey: "email") ?? ""
    @State private var message = ""
    @State private var isShowingMailView = false
    @State private var showAlert = false

    var body: some View {
        NavigationView {
            ZStack {
                LinearGradient(gradient: Gradient(colors: [Color(red: 0.54, green: 0.74, blue: 1), .white]), startPoint: .top, endPoint: .bottom)
                    .edgesIgnoringSafeArea(.all)

                VStack(spacing: 20) {
                    Spacer()

                    // Header
                    VStack(spacing: 10) {
                        ZStack {
                            Rectangle()
                                .foregroundColor(.white.opacity(0.7))
                                .frame(width: 346, height: 91)
                                .cornerRadius(25)
                                .shadow(radius: 2)

                            VStack {
                                Text("Get in Touch")
                                    .font(Font.custom("Poppins", size: 16).weight(.medium))
                                    .foregroundColor(Color(red: 0.39, green: 0.39, blue: 0.50))

                                Text("We're here to help!")
                                    .font(Font.custom("Roboto", size: 17))
                                    .foregroundColor(.black)

                                Text("Reach out via the form below.")
                                    .font(Font.custom("Poppins", size: 17))
                                    .foregroundColor(Color.gray)
                            }
                        }
                    }

                    // Form
                    VStack(alignment: .leading, spacing: 15) {
                        Text("Name")
                            .font(Font.custom("Roboto", size: 18))
                            .foregroundColor(.black)
                        TextField("Your Name", text: $name)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .padding(.horizontal)
                            .disabled(true)

                        Text("Email")
                            .font(Font.custom("Roboto", size: 18))
                            .foregroundColor(.black)
                        TextField("Your Email", text: $email)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .padding(.horizontal)
                            .disabled(true)

                        Text("Message")
                            .font(Font.custom("Roboto", size: 18))
                            .foregroundColor(.black)
                        TextEditor(text: $message)
                            .frame(height: 100)
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(Color.gray, lineWidth: 1)
                            )
                            .padding(.horizontal)
                    }
                    .padding(.horizontal, 40)

                    Spacer()

                    // Submit Button
                    Button(action: sendEmail) {
                        Text("Submit")
                            .font(Font.custom("Roboto", size: 18).weight(.medium))
                            .foregroundColor(.white)
                            .frame(width: 298, height: 50)
                            .background(Color.black)
                            .cornerRadius(4)
                    }
                    .shadow(color: Color.gray.opacity(0.5), radius: 10, y: 4)
                    .alert(isPresented: $showAlert) {
                        Alert(title: Text("Error"), message: Text("Please enter a message before submitting."), dismissButton: .default(Text("OK")))
                    }

                    Spacer().frame(height: 20)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
                .padding(.top, 20)

                // HEADER
                VStack {
                    ZStack {
                        Rectangle()
                            .foregroundColor(.white)
                            .frame(height: 85)
                            .ignoresSafeArea(edges: .top)

                        HStack {
                            Button(action: {
                                presentationMode.wrappedValue.dismiss()
                            }) {
                                Image(systemName: "chevron.left")
                                    .font(.system(size: 20, weight: .medium))
                                    .foregroundColor(.black)
                                    .padding(10)
                                    .fontWeight(.bold)
                            }

                            Spacer()

                            Text("Contact Us")
                                .font(Font.custom("Poppins", size: 16).weight(.medium))
                                .foregroundColor(.black)
                                .padding(.leading, -30)
                            Spacer()
                        }
                        .padding(.horizontal)
                        .padding(.top, -58)
                    }
                    Spacer()
                }
                .frame(maxWidth: .infinity, alignment: .top)
            }
        }
        .sheet(isPresented: $isShowingMailView) {
            MailView(
                email: "durgacharan844@gmail.com",
                subject: "User Inquiry from \(name)",
                body: message
            )
        }
    }

    private func sendEmail() {
        guard !message.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            showAlert = true
            return
        }

        if MFMailComposeViewController.canSendMail() {
            isShowingMailView = true
        } else {
            print("❌ Mail app is not configured!")
        }
    }
}
#Preview {
    ContactUsView()
}
