import SwiftUI

struct ProfileView: View {
    @Environment(\.presentationMode) var presentationMode
    @Binding var selectedTab: SampleView.Tab
    @Binding var showTabBar: Bool  // Binding to control tab bar visibility
    @State private var name: String = UserDefaults.standard.string(forKey: "name") ?? ""
    @State private var profileImage: Image? = Image("profileImage") // Default Image
    
    var body: some View {
        NavigationView {
            GeometryReader { geometry in
                ZStack {
                    // Background Gradient
                    LinearGradient(gradient: Gradient(colors: [Color(red: 0.54, green: 0.74, blue: 1), .white]), startPoint: .top, endPoint: .bottom)
                        .edgesIgnoringSafeArea(.all)
                    
                    VStack {
                        // Profile Image and Info Section
                        profileImage?
                            .resizable()
                            .scaledToFill()
                            .frame(width: geometry.size.width * 0.3, height: geometry.size.width * 0.3)
                            .clipShape(Circle())
                            .overlay(Circle().stroke(Color.white, lineWidth: 4))
                            .shadow(radius: 10)
                            .padding(.top, 20)
                        
                        ZStack {
                            LinearGradient(gradient: Gradient(colors: [Color(red: 1, green: 0.84, blue: 0), Color(red: 1, green: 0.92, blue: 0.66), Color(red: 1, green: 0.65, blue: 0)]), startPoint: .leading, endPoint: .trailing)
                                .cornerRadius(geometry.size.width * 0.05)
                                .frame(width: geometry.size.width * 0.9, height: geometry.size.height * 0.1)
                                .shadow(color: Color.black.opacity(0.5), radius: 10)
                            
                            VStack {
                                Text(name)
                                    .font(Font.custom("Roboto", size: geometry.size.width * 0.045).weight(.medium))
                                    .foregroundColor(.black)
                                Text("Your Details, All in One Place!")
                                    .font(Font.custom("Roboto", size: geometry.size.width * 0.035))
                                    .foregroundColor(Color.gray)
                            }
                        }
                        .padding(.top, 10)
                        
                        // Menu Options
                        VStack(spacing: geometry.size.height * 0.03) {
                            NavigationLink(destination: EditProfile().navigationBarBackButtonHidden(true)) {
                                ProfileMenuItem(icon: "pencil", title: "Edit Profile", width: geometry.size.width)
                            }
                            
                            NavigationLink(destination: ChangePasswordView().navigationBarBackButtonHidden(true)) {
                                ProfileMenuItem(icon: "lock.fill", title: "Change Password", width: geometry.size.width)
                            }
                            
                            NavigationLink(destination: LoginView(showTabBar: $showTabBar).navigationBarBackButtonHidden(true)) {
                                ProfileMenuItem(icon: "power", title: "Logout", width: geometry.size.width)
                            }
                        }
                        .padding(.top, geometry.size.height * 0.05)
                        .padding(.horizontal)
                        
                        Spacer()
                    }
                }
            }
        }
        .onAppear {
            loadImageFromUserDefaults()
        }
    }
    
    // ✅ Load Profile Image from UserDefaults
    func loadImageFromUserDefaults() {
        if let imageData = UserDefaults.standard.data(forKey: "profileImage"),
           let uiImage = UIImage(data: imageData) {
            profileImage = Image(uiImage: uiImage)
        }
    }
}

struct ProfileMenuItem: View {
    var icon: String
    var title: String
    var width: CGFloat
    
    var body: some View {
        HStack {
            Image(systemName: icon)
                .font(.system(size: width * 0.06))
                .foregroundColor(.black)
            Text(title)
                .font(Font.custom("Roboto", size: width * 0.045).weight(.medium))
                .foregroundColor(.black)
            Spacer()
        }
        .padding()
        .frame(width: width * 0.9)
        .background(Color.white)
        .cornerRadius(width * 0.03)
        .shadow(radius: 5)
    }
}

struct ProfileView_Previews: PreviewProvider {
    static var previews: some View {
        ProfileView(selectedTab: .constant(.home), showTabBar: .constant(true))
    }
}
