import SwiftUI

struct MccPictures: View {
    var selectedHall: Hall

    @State private var images: [String] = []
    @State private var isLoading = true
    @State private var errorMessage: String?
    @State private var selectedIndex: Int? = nil
    @Environment(\.presentationMode) var presentationMode

    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.7), .white]),
                           startPoint: .top, endPoint: .bottom)
                .edgesIgnoringSafeArea(.all)

            VStack(spacing: 0) {
                // Custom Header
                HStack {
                    Button(action: { presentationMode.wrappedValue.dismiss() }) {
                        Image(systemName: "chevron.left")
                            .font(.title2)
                            .foregroundColor(.black)
                            .padding()
                            .fontWeight(.bold)
                    }
                    Spacer()
                    Text(selectedHall.name)
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(.black)
                        .lineLimit(1)
                        .padding(.leading, -50)
                    Spacer()
                }
                .frame(height: 50)
                .padding(.horizontal)
                .background(Color.white)
                .padding(.top, -30)

                if isLoading {
                    ProgressView("Loading images...")
                        .progressViewStyle(CircularProgressViewStyle(tint: .white))
                        .font(.title3)
                        .padding(.top, 20)
                } else if let errorMessage = errorMessage {
                    Text("Error: \(errorMessage)")
                        .foregroundColor(.red)
                        .padding()
                } else if images.isEmpty {
                    Text("No images available")
                        .foregroundColor(.gray)
                        .padding()
                } else {
                    ScrollView {
                        VStack(spacing: 15) {
                            ForEach(images.indices, id: \.self) { index in
                                Button(action: {
                                    withAnimation {
                                        selectedIndex = index
                                    }
                                }) {
                                    HallImageView(imageURL: "\(APIHandler.baseURL)\(images[index])")
                                }
                            }
                        }
                        .padding()
                    }
                }
            }
            .padding(.top, 10)
            .onAppear { fetchImages() }

            // Full-Screen Image View
            if let selectedIndex = selectedIndex {
                FullScreenImageView(
                    images: images,
                    selectedIndex: Binding(
                        get: { selectedIndex },
                        set: { newValue in
                            self.selectedIndex = newValue
                        }
                    ),
                    isPresented: Binding(
                        get: { selectedIndex != nil },
                        set: { if !$0 { self.selectedIndex = nil } }
                    )
                )
            }
        }
        .navigationBarHidden(true)
    }

    private func fetchImages() {
        guard let hallID = selectedHall.id, !hallID.isEmpty else {
            self.errorMessage = "Invalid Hall ID"
            self.isLoading = false
            return
        }

        let urlString = "\(APIHandler.fetchImages)?hall_id=\(hallID)"
        guard let url = URL(string: urlString) else {
            self.errorMessage = "Invalid API URL"
            self.isLoading = false
            return
        }

        URLSession.shared.dataTask(with: url) { data, response, error in
            DispatchQueue.main.async {
                self.isLoading = false

                if let error = error {
                    self.errorMessage = "Network error: \(error.localizedDescription)"
                    return
                }

                guard let data = data else {
                    self.errorMessage = "No data received"
                    return
                }

                do {
                    if let jsonResponse = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] {
                        if let success = jsonResponse["success"] as? Bool, success,
                           let fetchedImages = jsonResponse["images"] as? [String] {
                            self.images = fetchedImages
                        } else {
                            self.errorMessage = jsonResponse["message"] as? String ?? "Failed to fetch images"
                        }
                    } else {
                        self.errorMessage = "Invalid JSON structure"
                    }
                } catch {
                    self.errorMessage = "JSON Parsing Error: \(error.localizedDescription)"
                }
            }
        }.resume()
    }
}

// MARK: - Hall Image View
struct HallImageView: View {
    let imageURL: String

    var body: some View {
        AsyncImage(url: URL(string: imageURL)) { phase in
            if let image = phase.image {
                image.resizable()
                    .scaledToFill()
                    .frame(width: UIScreen.main.bounds.width * 0.9, height: 250)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                    .shadow(color: Color.black.opacity(0.3), radius: 8, x: 5, y: 5)
            } else if phase.error != nil {
                Image(systemName: "photo.fill")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 50, height: 50)
                    .foregroundColor(.gray)
                    .padding()
            } else {
                ProgressView()
                    .frame(width: UIScreen.main.bounds.width * 0.9, height: 250)
                    .background(Color.gray.opacity(0.3))
                    .clipShape(RoundedRectangle(cornerRadius: 12))
            }
        }
    }
}

// MARK: - Full Screen Image View with Fixes
struct FullScreenImageView: View {
    var images: [String]
    @Binding var selectedIndex: Int
    @Binding var isPresented: Bool
    @State private var scale: CGFloat = 1.0

    var body: some View {
        ZStack {
            Color.black.opacity(0.9)
                .edgesIgnoringSafeArea(.all)

            VStack {
                // Close Button
                HStack {
                    Spacer()
                    Button(action: {
                        withAnimation(.spring()) {
                            isPresented = false
                        }
                    }) {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundColor(.white)
                            .font(.largeTitle)
                            .padding()
                    }
                }

                Spacer()

                // Image Display with Zoom and Double-Tap Zoom
                if let imageUrl = URL(string: APIHandler.baseURL + images[selectedIndex]) {
                    AsyncImage(url: imageUrl) { phase in
                        if let image = phase.image {
                            image
                                .resizable()
                                .scaledToFit()
                                .frame(width: UIScreen.main.bounds.width * 0.95)
                                .cornerRadius(12)
                                .shadow(radius: 8)
                                .scaleEffect(scale)
                                .gesture(
                                    MagnificationGesture()
                                        .onChanged { value in
                                            scale = value
                                        }
                                        .onEnded { _ in
                                            withAnimation {
                                                scale = 1.0
                                            }
                                        }
                                )
                                .onTapGesture(count: 2) { // Double-Tap to Zoom
                                    withAnimation {
                                        scale = scale == 1.0 ? 2.5 : 1.0
                                    }
                                }
                        } else {
                            ProgressView()
                                .frame(width: UIScreen.main.bounds.width * 0.95, height: UIScreen.main.bounds.height * 0.6)
                                .background(Color.gray.opacity(0.3))
                                .cornerRadius(12)
                        }
                    }
                }

                Spacer()

                // Navigation Buttons
                HStack(spacing: 30) {
                    Button(action: {
                        if selectedIndex > 0 {
                            selectedIndex -= 1
                        }
                    }) {
                        Image(systemName: "chevron.left.circle.fill")
                            .font(.largeTitle)
                            .foregroundColor(selectedIndex > 0 ? .white : .gray)
                            .padding()
                    }
                    .disabled(selectedIndex == 0)

                    Button(action: {
                        if selectedIndex < images.count - 1 {
                            selectedIndex += 1
                        }
                    }) {
                        Image(systemName: "chevron.right.circle.fill")
                            .font(.largeTitle)
                            .foregroundColor(selectedIndex < images.count - 1 ? .white : .gray)
                            .padding()
                    }
                    .disabled(selectedIndex == images.count - 1)
                }
                .padding(.bottom, 20)
            }
        }
    }
}

// MARK: - Preview
#Preview{
    MccPictures(selectedHall: Hall(id: "1", name: "Grand Hall", rating: "", imageName: "", location: "City Center"))
}
