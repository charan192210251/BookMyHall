import SwiftUI
import PhotosUI

struct EditProfile: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var profileImage: Image? = Image("profileImage")
    @State private var selectedImage: UIImage?
    @State private var isImagePickerPresented = false
    @State private var name: String = UserDefaults.standard.string(forKey: "name") ?? ""
    @State private var email: String = UserDefaults.standard.string(forKey: "email") ?? ""
    @State private var phoneNumber: String = UserDefaults.standard.string(forKey: "phoneNumber") ?? ""
    @State private var showAlert = false
    @State private var alertMessage = ""

    var body: some View {
        GeometryReader { geometry in
            VStack(spacing: 0) {
                // ✅ Fixed Header
                ZStack {
                    Rectangle()
                        .frame(height: 40)
                        .foregroundColor(.white)
                        //.shadow(color: Color.gray.opacity(0.3), radius: 5, x: 0, y: 3)

                    HStack {
                        Button(action: { presentationMode.wrappedValue.dismiss() }) {
                            Image(systemName: "chevron.left")
                                .font(.system(size: 20, weight: .bold))
                                .foregroundColor(.black)
                        }
                        Spacer()
                        Text("Edit Profile")
                            .offset(x:16)
                            .font(.system(size: 20))
                            .foregroundColor(.black)
                        Spacer()
                        // Placeholder for spacing balance
                        Spacer().frame(width: 44)
                    }
                    .padding(.horizontal)
                    
                }

                ZStack {
                    LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.6), .white]), startPoint: .top, endPoint: .bottom)
                        .edgesIgnoringSafeArea(.all)

                    ScrollView {
                        VStack(spacing: 20) {
                            // ✅ Profile Image Section
                            Button(action: { isImagePickerPresented = true }) {
                                profileImage?
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width: geometry.size.width * 0.35, height: geometry.size.width * 0.35)
                                    .clipShape(Circle())
                                    .shadow(color: Color.black.opacity(0.5), radius: 5)
                                    .overlay(Circle().stroke(Color.white, lineWidth: 4))
                            }
                            .sheet(isPresented: $isImagePickerPresented) {
                                ImagePicker(selectedImage: $selectedImage, profileImage: $profileImage)
                            }

                            // ✅ Form Fields
                            VStack(alignment: .leading, spacing: 15) {
                                CustomTextField(title: "Name", text: $name)
                                CustomTextField(title: "Email", text: $email, keyboardType: .emailAddress)
                                CustomTextField(title: "Phone Number", text: $phoneNumber, keyboardType: .numberPad, limit: 10)
                            }
                            .padding(.horizontal, 20)

                            // ✅ Update Button
                            Button("Update") {
                                updateUserProfile()
                            }
                            .frame(width: geometry.size.width * 0.6, height: 45)
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                            .shadow(radius: 5)
                        }
                        .padding(.top, 30)
                        .padding(.bottom, 50) // Prevents button from sticking at the bottom
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
            .onAppear {
                loadImageFromUserDefaults()
            }
            .alert(isPresented: $showAlert) {
                Alert(title: Text("Profile Update"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
            }
        }
    }

    func updateUserProfile() {
        guard let userId = UserDefaults.standard.string(forKey: "user_id"), !userId.isEmpty else {
            alertMessage = "User ID not found! Please log in again."
            showAlert = true
            return
        }

        let parameters: [String: String] = [
            "user_id": userId,
            "name": name,
            "phone": phoneNumber,
            "email": email.lowercased()
        ]

        APIService.shared.sendFormDataRequest(endpoint: APIHandler.editProfile, parameters: parameters) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let response):
                    if let status = response["status"] as? Bool, status {
                        alertMessage = "Profile updated successfully!"
                        UserDefaults.standard.set(name, forKey: "name")
                        UserDefaults.standard.set(email.lowercased(), forKey: "email")
                        UserDefaults.standard.set(phoneNumber, forKey: "phoneNumber")
                    } else {
                        alertMessage = response["message"] as? String ?? "Update failed"
                    }
                case .failure(let error):
                    alertMessage = "Network error: \(error.localizedDescription)"
                }
                showAlert = true
            }
        }
    }

    func loadImageFromUserDefaults() {
        if let imageData = UserDefaults.standard.data(forKey: "profileImage"),
           let uiImage = UIImage(data: imageData) {
            profileImage = Image(uiImage: uiImage)
        }
    }
}

// ✅ Custom TextField
struct CustomTextField: View {
    var title: String
    @Binding var text: String
    var keyboardType: UIKeyboardType = .default
    var limit: Int?

    var body: some View {
        VStack(alignment: .leading) {
            Text(title)
                .font(.headline)
                .foregroundColor(.black)
            
            TextField("Enter \(title.lowercased())", text: $text)
                .keyboardType(keyboardType)
                .padding()
                .background(Color.gray.opacity(0.2))
                .cornerRadius(5)
                .onChange(of: text) { newValue in
                    if let limit = limit {
                        text = String(newValue.prefix(limit))
                    }
                }
        }
    }
}

// ✅ Image Picker
struct ImagePicker: UIViewControllerRepresentable {
    @Binding var selectedImage: UIImage?
    @Binding var profileImage: Image?

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.delegate = context.coordinator
        picker.sourceType = .photoLibrary
        return picker
    }

    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}

    class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
        let parent: ImagePicker

        init(_ parent: ImagePicker) {
            self.parent = parent
        }

        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
            if let uiImage = info[.originalImage] as? UIImage {
                parent.selectedImage = uiImage
                parent.profileImage = Image(uiImage: uiImage)

                if let imageData = uiImage.jpegData(compressionQuality: 0.8) {
                    UserDefaults.standard.set(imageData, forKey: "profileImage")
                }
            }
            picker.dismiss(animated: true)
        }
    }
}

// ✅ Preview
struct EditProfile_Previews: PreviewProvider {
    static var previews: some View {
        EditProfile()
    }
}
