import SwiftUI

struct MyReviewsView: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var reviews: [UserReview] = []
    @State private var isLoading = true
    @State private var errorMessage: String?

    @AppStorage("user_id") private var user_id: String = ""

    var body: some View {
        GeometryReader { geometry in
            ZStack {
                LinearGradient(gradient: Gradient(colors: [Color(red: 0.54, green: 0.74, blue: 1), .white]),
                               startPoint: .top, endPoint: .bottom)
                    .edgesIgnoringSafeArea(.all)

                VStack(spacing: 0) {
                    VStack {
                        HStack {
                            Button(action: { presentationMode.wrappedValue.dismiss() }) {
                                Image(systemName: "chevron.left")
                                    .font(.system(size: geometry.size.width * 0.05, weight: .bold))
                                    .foregroundColor(.black)
                                    .padding(.leading, 8)
                            }
                            Spacer()
                            Text("My Reviews")
                                .font(Font.custom("Roboto", size: geometry.size.width * 0.05).weight(.medium))
                                .foregroundColor(.black)
                            Spacer()
                            Image(systemName: "chevron.left")  // Invisible chevron for symmetry
                                .opacity(0)
                        }
                        .padding(.horizontal, 16)
                    }
                    .frame(height: geometry.size.height * 0.05)
                    .background(Color.white)

                    if isLoading {
                        ProgressView("Loading...")
                            .progressViewStyle(CircularProgressViewStyle(tint: .white))
                            .padding()
                    } else if let errorMessage = errorMessage {
                        Text(errorMessage)
                            .foregroundColor(.red)
                            .padding()
                    } else if reviews.isEmpty {
                        Text("No reviews found")
                            .foregroundColor(.black)
                            .padding()
                    } else {
                        ScrollView {
                            VStack(spacing: 15) {
                                ForEach(reviews, id: \.review_id) { review in
                                    UserReviewCard(review: review, onDelete: deleteReview)
                                }
                            }
                            .padding()
                        }
                    }
                    Spacer()
                }
            }
            .navigationBarHidden(true)
            .onAppear {
                fetchMyReviews()
            }
        }
    }

    // ✅ Fetch user reviews
    private func fetchMyReviews() {
        guard !user_id.isEmpty else {
            self.errorMessage = "User ID not found"
            self.isLoading = false
            return
        }

        guard let url = URL(string: "http://localhost/BookMyHall/fetchReviews.php") else { return }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        let body = "user_id=\(user_id)"
        request.httpBody = body.data(using: .utf8)
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                isLoading = false
                if let error = error {
                    errorMessage = "Error: \(error.localizedDescription)"
                    return
                }
                guard let data = data else {
                    errorMessage = "No data received"
                    return
                }

                do {
                    let decodedResponse = try JSONDecoder().decode(ReviewResponse.self, from: data)
                    if decodedResponse.status {
                        self.reviews = decodedResponse.reviews
                    } else {
                        errorMessage = decodedResponse.message ?? "Failed to load reviews."
                    }
                } catch {
                    errorMessage = "Failed to decode response"
                    print("🔴 Decoding Error: \(error)")
                }
            }
        }.resume()
    }

    // ✅ Delete review function
    private func deleteReview(_ reviewID: Int) {
        guard let url = URL(string: "http://localhost/BookMyHall/deleteReview.php") else { return }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        let body = "review_id=\(reviewID)"
        request.httpBody = body.data(using: .utf8)
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    errorMessage = "Error: \(error.localizedDescription)"
                    return
                }
                guard let data = data else {
                    errorMessage = "No data received"
                    return
                }

                do {
                    let decodedResponse = try JSONDecoder().decode(DeleteResponse.self, from: data)
                    if decodedResponse.status {
                        self.reviews.removeAll { $0.review_id == reviewID }
                    } else {
                        errorMessage = decodedResponse.message ?? "Failed to delete review."
                    }
                } catch {
                    errorMessage = "Failed to decode response"
                    print("🔴 Decoding Error: \(error)")
                }
            }
        }.resume()
    }
}

// ✅ Review Card with Delete Option
struct UserReviewCard: View {
    let review: UserReview
    var onDelete: (Int) -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("User: \(review.user_name)")
                    .font(.headline)
                    .foregroundColor(.white)

                Spacer()

                // ⚪ 3-dot Menu Button
                Menu {
                    Button(role: .destructive) {
                        onDelete(review.review_id)  // Call delete function
                    } label: {
                        Label("Delete", systemImage: "trash")
                    }
                } label: {
                    Image(systemName: "ellipsis")
                        .font(.title2)
                        .foregroundColor(.white)
                }
            }

            HStack {
                Text("Rating: \(review.rating, specifier: "%.1f") ⭐")
                    .font(.subheadline)
                    .foregroundColor(.yellow)
                Spacer()
            }

            Text("Reviewed on:")
                .font(.caption)
                .fontWeight(.bold)
                .foregroundColor(.white)

            Text(review.created_at)
                .font(.caption)
                .foregroundColor(.white)

            Text(review.comment)
                .font(.body)
                .foregroundColor(.white)
                .lineLimit(3)
        }
        .padding()
        .background(Color.black.opacity(0.3))
        .cornerRadius(10)
        .shadow(radius: 3)
    }
}

// ✅ Review & Delete Models
struct UserReview: Codable, Identifiable {
    let id = UUID()
    let review_id: Int
    let user_id: Int
    let hall_id: Int
    let rating: Double
    let comment: String
    let created_at: String
    let user_name: String
}

struct ReviewResponse: Codable {
    let status: Bool
    let message: String?
    let reviews: [UserReview]
}

struct DeleteResponse: Codable {
    let status: Bool
    let message: String?
}

// ✅ Preview
struct MyReviewsView_Previews: PreviewProvider {
    static var previews: some View {
        MyReviewsView()
    }
}
