import SwiftUI

struct ChangePasswordView: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var oldPassword: String = ""
    @State private var newPassword: String = ""
    @State private var confirmPassword: String = ""
    @State private var showOldPassword: Bool = false
    @State private var showNewPassword: Bool = false
    @State private var showConfirmPassword: Bool = false
    @State private var isLoading = false
    
    @State private var showPopup = false // Controls popup alert visibility
    @State private var popupMessage = "" // Message to display in the popup

    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [Color(red: 0.54, green: 0.74, blue: 1), .white]),
                           startPoint: .top, endPoint: .bottom)
                .edgesIgnoringSafeArea(.all)

            VStack {
                // Back Button
                HStack {
                    Button(action: { presentationMode.wrappedValue.dismiss() }) {
                        Image(systemName: "chevron.left")
                            .font(.title2)
                            .foregroundColor(.black)
                            .padding(.leading,-10)
                            .fontWeight(.bold)
                    }
                    Spacer()
                }
                
                // Title
                Text("Change Password")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .padding(.top, 10)
                
                // Password Fields
                PasswordField(title: "Old Password", text: $oldPassword, showPassword: $showOldPassword)
                PasswordField(title: "New Password", text: $newPassword, showPassword: $showNewPassword)
                PasswordField(title: "Confirm Password", text: $confirmPassword, showPassword: $showConfirmPassword)

                // Update Password Button
                Button(action: {
                    validateAndChangePassword()
                }) {
                    Text("Update Password")
                        .frame(maxWidth: .infinity)
                        .frame(height: 50)
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                        .font(.headline)
                        .shadow(radius: 5)
                }
                .padding(.top, 20)

                if isLoading {
                    ProgressView().padding()
                }

                Spacer()
            }
            .padding(.horizontal, 30)
        }
        .alert(isPresented: $showPopup) {
            Alert(
                title: Text("Password Update"),
                message: Text(popupMessage),
                dismissButton: .default(Text("OK"))
            )
        }
    }

    // Validate Input and Call API
    private func validateAndChangePassword() {
        guard !oldPassword.isEmpty, !newPassword.isEmpty, !confirmPassword.isEmpty else {
            showPopup(message: "All fields are required")
            return
        }

        guard newPassword == confirmPassword else {
            showPopup(message: "New passwords do not match")
            return
        }

        guard let userId = UserDefaults.standard.string(forKey: "user_id") else {
            showPopup(message: "User not found")
            return
        }

        isLoading = true

        let parameters: [String: String] = [
            "user_id": userId,
            "old_password": oldPassword,
            "new_password": newPassword
        ]

        APIService.shared.sendFormDataRequest(endpoint: APIHandler.baseURL + "changePassword.php", parameters: parameters) { result in
            DispatchQueue.main.async {
                isLoading = false
                switch result {
                case .success(let response):
                    if let status = response["status"] as? Bool, status {
                        showPopup(message: "Password changed successfully!")
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                            presentationMode.wrappedValue.dismiss()
                        }
                    } else {
                        showPopup(message: response["message"] as? String ?? "Failed to update password")
                    }
                case .failure(let error):
                    showPopup(message: error.localizedDescription)
                }
            }
        }
    }

    private func showPopup(message: String) {
        popupMessage = message
        showPopup = true
    }
}

// 🔹 Reusable Password Field Component
struct PasswordField: View {
    let title: String
    @Binding var text: String
    @Binding var showPassword: Bool

    var body: some View {
        VStack(alignment: .leading) {
            Text(title)
                .font(.headline)
                .foregroundColor(.black)

            HStack {
                if showPassword {
                    TextField("Enter \(title.lowercased())", text: $text)
                        .textContentType(.password)
                } else {
                    SecureField("Enter \(title.lowercased())", text: $text)
                }

                Button(action: {
                    withAnimation(.easeInOut(duration: 0.2)) {
                        showPassword.toggle()
                    }
                }) {
                    Image(systemName: showPassword ? "eye.slash" : "eye")
                        .foregroundColor(.gray)
                }
            }
            .padding()
            .background(Color.gray.opacity(0.2))
            .cornerRadius(5)
        }
        .padding(.top, 10)
    }
}

struct ChangePasswordView_Previews: PreviewProvider {
    static var previews: some View {
        ChangePasswordView()
    }
}
