import SwiftUI

struct BookingRequestsView: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var bookingRequests: [BookingRequest] = []
    @State private var isLoading = false

    func fetchBookingRequests() {
        isLoading = true
        let parameters: [String: String] = ["user_id": "0"]

        APIService.shared.sendFormDataRequest(endpoint: APIHandler.fetchBookings, parameters: parameters) { result in
            DispatchQueue.main.async {
                isLoading = false
                switch result {
                case .success(let data):
                    if let bookings = data["bookings"] as? [[String: Any]] {
                        self.bookingRequests = bookings.compactMap { BookingRequest(from: $0) }
                    }
                case .failure(let error):
                    print("Error fetching bookings: \(error.localizedDescription)")
                }
            }
        }
    }

    func updateBookingStatus(bookingId: Int, status: String) {
        let parameters: [String: String] = [
            "booking_id": "\(bookingId)",
            "status": status,
            "user_id": "0"
        ]

        APIService.shared.sendFormDataRequest(endpoint: APIHandler.updateBooking, parameters: parameters) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let data):
                    if let success = data["success"] as? Bool, success {
                        print("Booking status updated to \(status)")
                        if let index = self.bookingRequests.firstIndex(where: { $0.bookingId == bookingId }) {
                            withAnimation {
                                self.bookingRequests[index].status = status
                            }
                        }
                    } else {
                        print("Failed to update booking status: \(data["message"] ?? "No message available")")
                    }
                case .failure(let error):
                    print("Error updating booking status: \(error.localizedDescription)")
                }
            }
        }
    }

    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.7), .white]), startPoint: .top, endPoint: .bottom)
                .edgesIgnoringSafeArea(.all)

            VStack(spacing: 20) {
                // Back Button (Kept Unchanged)
                HStack {
                    Button(action: {
                        presentationMode.wrappedValue.dismiss()
                    }) {
                        Image(systemName: "chevron.left")
                            .font(.system(size: 20, weight: .medium))
                            .foregroundColor(.black)
                            .fontWeight(.bold)
                    }
                    Spacer()
                }
                .padding()
                .offset(x:5,y: 67)
                Text("Booking Requests")
                    .font(.largeTitle)
                    .fontWeight(.heavy)
                    .foregroundColor(.black)

                if isLoading {
                    ProgressView("Loading...")
                        .progressViewStyle(CircularProgressViewStyle(tint: .black))
                        .padding()
                        .transition(.opacity)
                } else {
                    ScrollView {
                        VStack(spacing: 20) {
                            ForEach(bookingRequests) { request in
                                BookingRequestCard(bookingRequest: request, onApprove: {
                                    updateBookingStatus(bookingId: request.bookingId, status: "confirmed")
                                }, onReject: {
                                    updateBookingStatus(bookingId: request.bookingId, status: "rejected")
                                })
                                .padding(.horizontal)
                                .transition(.scale)
                            }
                        }
                        .padding(.top, 10)
                    }
                }
            }
            .padding(.top, -40)
        }
        .onAppear {
            fetchBookingRequests()
        }
    }
}

// MARK: - Booking Request Model
struct BookingRequest: Identifiable {
    var id: Int
    var name: String
    var hall: String
    var date: String
    var status: String
    var bookingId: Int

    init(from dictionary: [String: Any]) {
        self.id = dictionary["booking_id"] as? Int ?? 0
        self.name = dictionary["user_id"] as? String ?? ""
        self.hall = dictionary["hall_name"] as? String ?? ""
        self.date = dictionary["booking_date"] as? String ?? ""
        self.status = dictionary["status"] as? String ?? ""
        self.bookingId = dictionary["booking_id"] as? Int ?? 0
    }
}

// MARK: - Booking Request Card
struct BookingRequestCard: View {
    var bookingRequest: BookingRequest
    var onApprove: () -> Void
    var onReject: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            HStack {
                Text("Hall: \(bookingRequest.hall)")
                    .font(.headline)
                    .frame(maxWidth: .infinity, alignment: .leading)
                
                Text("Date: \(bookingRequest.date)")
                    .font(.subheadline)
                    .frame(maxWidth: .infinity, alignment: .trailing)
            }

            Text("Status: \(bookingRequest.status.capitalized)")
                .font(.subheadline)
                .foregroundColor(statusColor(bookingRequest.status))
                .bold()

            HStack {
                Spacer()
                
                Button(action: {
                    withAnimation(.spring()) { onApprove() }
                }) {
                    HStack {
                        Image(systemName: "checkmark.circle.fill")
                        Text("Approve")
                    }
                    .padding(.vertical, 8)
                    .padding(.horizontal, 16)
                    .foregroundColor(.white)
                    .background(Color.green)
                    .cornerRadius(8)
                    .shadow(radius: 3)
                }
                .buttonStyle(PlainButtonStyle())
                .hoverEffect(.lift)

                Spacer()

                Button(action: {
                    withAnimation(.spring()) { onReject() }
                }) {
                    HStack {
                        Image(systemName: "xmark.circle.fill")
                        Text("Reject")
                    }
                    .padding(.vertical, 8)
                    .padding(.horizontal, 16)
                    .foregroundColor(.white)
                    .background(Color.red)
                    .cornerRadius(8)
                    .shadow(radius: 3)
                }
                .buttonStyle(PlainButtonStyle())
                .hoverEffect(.lift)

                Spacer()
            }
        }
        .padding()
        .frame(maxWidth: .infinity)
        .background(Color.white.opacity(0.8))
        .cornerRadius(12)
        .shadow(radius: 3)
        .hoverEffect(.highlight)
        .animation(.easeInOut(duration: 0.3), value: bookingRequest.status)
    }

    func statusColor(_ status: String) -> Color {
        switch status {
        case "pending": return .orange
        case "confirmed": return .green
        case "rejected": return .red
        default: return .gray
        }
    }
}

// MARK: - Preview
struct BookingRequestsView_Previews: PreviewProvider {
    static var previews: some View {
        BookingRequestsView()
    }
}
