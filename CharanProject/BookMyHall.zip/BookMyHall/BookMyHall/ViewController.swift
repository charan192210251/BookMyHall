import UIKit
import SwiftUI

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Step 1: Create the SwiftUI view (ContentView)
        let swiftUIView = ContentView()
        
        // Step 2: Embed the SwiftUI view in a UIHostingController
        let hostingController = UIHostingController(rootView: swiftUIView)
        
        // Step 3: Add the UIHostingController as a child view controller
        addChild(hostingController)
        view.addSubview(hostingController.view)
        
        // Step 4: Set the frame or constraints for the SwiftUI view
        hostingController.view.frame = view.bounds
        hostingController.view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        
        // Final Step: Notify the hosting controller that it has been added as a child
        hostingController.didMove(toParent: self)
        
    }
}
