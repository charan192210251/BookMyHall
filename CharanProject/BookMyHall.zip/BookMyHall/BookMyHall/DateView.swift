import SwiftUI

struct DateView: View {
    @State private var selectedDate = Date()
    @State private var startTime = Date()
    @State private var endTime = Calendar.current.date(byAdding: .hour, value: 1, to: Date()) ?? Date()
    var selectedHall: Hall // Property to receive the selected hall
    @Environment(\.presentationMode) var presentationMode

    var body: some View {
        NavigationStack {
            ZStack {
                // Gradient background
                LinearGradient(gradient: Gradient(colors: [Color(red: 0.54, green: 0.74, blue: 1), .white]), startPoint: .top, endPoint: .bottom)
                    .edgesIgnoringSafeArea(.all)
                
                VStack {
                    // Header Section - Always at the Top
                    VStack {
                        HStack {
                            Button(action: {
                                presentationMode.wrappedValue.dismiss()
                            }) {
                                Image(systemName: "chevron.left")
                                    .font(.system(size: 20, weight: .medium))
                                    .foregroundColor(.black)
                                    
                                    .fontWeight(.bold)
                            }
                            Spacer()
                            Text("Book Your Hall")
                                .font(Font.custom("Roboto", size: 16).weight(.semibold))
                                .foregroundColor(.black)
                                .offset(x: -16)
                            Spacer()
                        }
                        .padding(.top, 50)
                        .frame(height: 80)
                        .padding(.horizontal)
                        .background(Color.white)
                        
                    }
                    .ignoresSafeArea(edges: .top) // Ensure header stays at the very top

                    // Centering the Content
                    VStack(spacing: 20) {
                        Text("Select Date and Time")
                            .font(Font.custom("Roboto", size: 16).weight(.semibold))
                            .foregroundColor(Color.black)
                        
                        // Date Picker - Only allow today or future dates
                        DatePicker("Select Date", selection: $selectedDate, in: Date()..., displayedComponents: .date)
                            .datePickerStyle(CompactDatePickerStyle())
                            .padding()
                            .background(Color.white)
                            .cornerRadius(10)
                            .shadow(radius: 5)
                            .padding(.horizontal)
                        
                        // Start Time Picker
                        DatePicker("Start Time", selection: $startTime, displayedComponents: .hourAndMinute)
                            .datePickerStyle(CompactDatePickerStyle())
                            .padding()
                            .background(Color.white)
                            .cornerRadius(10)
                            .shadow(radius: 5)
                            .padding(.horizontal)
                            .onChange(of: startTime) { newStartTime in
                                // Ensure end time is always after start time
                                if endTime <= newStartTime {
                                    endTime = Calendar.current.date(byAdding: .hour, value: 1, to: newStartTime) ?? newStartTime
                                }
                            }
                        
                        // End Time Picker
                        DatePicker("End Time", selection: $endTime, displayedComponents: .hourAndMinute)
                            .datePickerStyle(CompactDatePickerStyle())
                            .padding()
                            .background(Color.white)
                            .cornerRadius(10)
                            .shadow(radius: 5)
                            .padding(.horizontal)
                        
                        // Booking Button
                        NavigationLink(destination: ConfirmBooking(selectedHall: selectedHall, selectedDate: selectedDate, startTime: startTime, endTime: endTime).navigationBarBackButtonHidden(true)) {
                            Text("Book Now")
                                .font(.headline)
                                .foregroundColor(.white)
                                .padding()
                                .background(LinearGradient(gradient: Gradient(colors: [
                                    Color.green,
                                    Color.green.opacity(0.8)
                                ]), startPoint: .leading, endPoint: .trailing))
                                .cornerRadius(20.96)
                                .shadow(radius: 10)
                        }
                        .padding(.top, 100)
                    }
                    .frame(maxHeight: .infinity, alignment: .center) // Ensures content is centered
                }
            }
        }
    }
}

struct DateView_Previews: PreviewProvider {
    static var previews: some View {
        DateView(selectedHall: Hall(name: "Sample Hall", rating: "4.5 (200 reviews)", imageName: "sampleImage"))
    }
}
