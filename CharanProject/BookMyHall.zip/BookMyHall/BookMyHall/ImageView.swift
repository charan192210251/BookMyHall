import SwiftUI

struct ImageView: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var halls: [Hall] = []
    @State private var isLoading = false
    @State private var errorMessage: String?
    @State private var searchText = ""

    var filteredHalls: [Hall] {
        searchText.isEmpty ? halls : halls.filter { $0.name.lowercased().contains(searchText.lowercased()) }
    }

    var body: some View {
        NavigationView {
            ZStack {
                // Gradient Background
                LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.7), .white]),
                               startPoint: .top, endPoint: .bottom)
                .edgesIgnoringSafeArea(.all)

                VStack {
                    // Back Button
                    Button(action: {
                        presentationMode.wrappedValue.dismiss()
                    }) {
                        Image(systemName: "chevron.left")
                            .font(.system(size: 20, weight: .medium))
                            .foregroundColor(.black)
                            .fontWeight(.bold)
                            .padding()
                            .frame(width: 40, height: 40)
                            .background(Color.clear)
                            .cornerRadius(20)
                    }
                    .offset(x: -168, y: 60)

                    Text("Upload Images")
                        .font(.largeTitle)
                        .fontWeight(.heavy)
                        .foregroundColor(.black)

                    if isLoading {
                        ProgressView("Loading...")
                            .progressViewStyle(CircularProgressViewStyle(tint: .black))
                            .padding()
                    } else if let errorMessage = errorMessage {
                        Text(errorMessage)
                            .foregroundColor(.red)
                            .multilineTextAlignment(.center)
                            .padding()
                    } else {
                        // Search Bar
                        SearchBar(searchText: $searchText)

                        // Halls List
                        ScrollView {
                            VStack(spacing: 15) {
                                ForEach(filteredHalls) { hall in
                                    NavigationLink(destination: UploadImagesView(hallID: hall.id ?? "").navigationBarBackButtonHidden(true)) {
                                        HallCardView(hall: hall)
                                    }
                                }
                            }
                            .padding(.top, 10)
                        }
                    }
                }
                .padding(.top, -40)
            }
            .onAppear {
                fetchHalls()
            }
        }
    }

    // Fetching halls data
    private func fetchHalls() {
        isLoading = true
        errorMessage = nil

        guard let userId = UserDefaults.standard.string(forKey: "user_id") else {
            self.errorMessage = "User ID is missing."
            self.isLoading = false
            return
        }

        let endpoint = APIHandler.fetchHalls
        let parameters: [String: String] = ["user_id": userId]

        APIService.shared.sendFormDataRequest(endpoint: endpoint, parameters: parameters) { result in
            DispatchQueue.main.async {
                isLoading = false
                switch result {
                case .success(let jsonResponse):
                    if let hallsData = jsonResponse["halls"] as? [[String: Any]] {
                        self.halls = hallsData.compactMap { hallData in
                            guard let name = hallData["name"] as? String,
                                  let imageName = hallData["imageName"] as? String else {
                                return nil
                            }
                            return Hall(id: hallData["id"] as? String,
                                        name: name,
                                        rating: hallData["rating"] as? String ?? "",
                                        imageName: imageName,
                                        description: hallData["description"] as? String,
                                        location: hallData["location"] as? String,
                                        capacity: hallData["capacity"] as? String,
                                        facility: hallData["facility"] as? String,
                                        services: hallData["services"] as? String,
                                        availability: hallData["availability"] as? String)
                        }
                    } else {
                        self.errorMessage = "Failed to load halls."
                    }
                case .failure(let error):
                    self.errorMessage = error.localizedDescription
                }
            }
        }
    }
}

// MARK: - HallCardView Component
struct HallCardView: View {
    let hall: Hall

    var body: some View {
        HStack {
            if let imageURL = URL(string: hall.imageName), hall.imageName.contains("http") {
                AsyncImage(url: imageURL) { image in
                    image.resizable().scaledToFill()
                } placeholder: {
                    Rectangle().fill(Color.gray.opacity(0.3))
                }
                .frame(width: 80, height: 80)
                .cornerRadius(10)
                .clipped()
            } else {
                Image(hall.imageName)
                    .resizable()
                    .scaledToFill()
                    .frame(width: 80, height: 80)
                    .cornerRadius(10)
                    .clipped()
            }

            VStack(alignment: .leading, spacing: 5) {
                Text(hall.name)
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundColor(.black)
                    .lineLimit(1)
            }

            Spacer()
        }
        .padding()
        .background(Color.white.opacity(0.6))
        .cornerRadius(12)
        .shadow(radius: 5)
        .padding(.horizontal)
    }
}

// MARK: - SearchBar Component
struct SearchBar: View {
    @Binding var searchText: String

    var body: some View {
        HStack {
            Image(systemName: "magnifyingglass")
                .foregroundColor(.blue)
                .padding(.leading, 10)

            TextField("Search Halls", text: $searchText)
                .padding()
                .background(Color.white)
                .cornerRadius(8)
        }
        .frame(height: 50)
        .background(Color.white)
        .cornerRadius(24)
        .shadow(radius: 5)
        .padding(.horizontal, 20)
    }
}


// MARK: - Preview
struct ImageView_Previews: PreviewProvider {
    static var previews: some View {
        ImageView()
    }
}
