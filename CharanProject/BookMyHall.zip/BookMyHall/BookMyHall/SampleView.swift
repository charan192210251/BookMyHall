import SwiftUI

struct SampleView: View {
    @State private var selectedTab: Tab = .home // Manage tab selection
    @State private var showTabBar: Bool = true // Control tab bar visibility

    enum Tab {
        case home, search, profile
    }

    var body: some View {
        GeometryReader { geometry in
            ZStack {
                // Background gradient
                LinearGradient(gradient: Gradient(colors: [Color(red: 0.54, green: 0.74, blue: 1), .white]), startPoint: .top, endPoint: .bottom)
                    .edgesIgnoringSafeArea(.all)

                VStack(spacing: 0) {
                    // Content based on selected tab
                    VStack {
                        switch selectedTab {
                        case .home:
                            MainView(selectedTab: $selectedTab, showTabBar: $showTabBar)
                                .id(selectedTab)
                                .padding(.bottom, -122) // Prevent layout shift
                        case .search:
                            HallView( selectedTab: .constant(.home),
                                      showTabBar: .constant(true))
                                .id(selectedTab)
                        case .profile:
                            ProfileView(selectedTab: $selectedTab, showTabBar: $showTabBar)
                                .id(selectedTab)
                                .padding(.bottom, -72)
                        }
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .id(selectedTab)

                    // Conditionally show tab bar
                    if showTabBar && (selectedTab == .home || selectedTab == .search || selectedTab == .profile) {
                        ZStack {
                            LinearGradient(
                                gradient: Gradient(colors: [
                                    Color(red: 0.11, green: 0.10, blue: 0.16).opacity(0.8),
                                    Color(red: 0.13, green: 0.13, blue: 0.16).opacity(0.9)
                                ]),
                                startPoint: .top,
                                endPoint: .bottom
                            )
                            .frame(height: 80)
                            .cornerRadius(25)
                            .shadow(color: Color.black.opacity(0.3), radius: 10, y: 4)

                            HStack {
                                // Spacer before first button
                                Spacer()
                                BottomTabButton(icon: "house.fill", title: "Home", isSelected: selectedTab == .home) {
                                    selectedTab = .home
                                    print("Selected Home")
                                }
                                // Spacer between buttons
                                Spacer()
                                BottomTabButton(icon: "magnifyingglass", title: "Search", isSelected: selectedTab == .search) {
                                    selectedTab = .search
                                    print("Selected Search")
                                }
                                // Spacer between buttons
                                Spacer()
                                BottomTabButton(icon: "person.fill", title: "Profile", isSelected: selectedTab == .profile) {
                                    selectedTab = .profile
                                    print("Selected Profile")
                                }
                                // Spacer after last button
                                Spacer()
                            }
                        }
                        .frame(width: geometry.size.width * 0.9, height: 60.0) // Adjusted width to 90% of screen width
                        .padding([.bottom, .trailing], 22.0) // Apply padding to bottom and trailing
                        .padding(.leading, 20) // Added left padding to the tab bar
                    }
                }
            }
            .onAppear {
                // Ensure the layout is stable on appear
                DispatchQueue.main.async {
                    self.showTabBar = true
                }
            }
        }
    }
}

struct BottomTabButton: View {
    var icon: String
    var title: String
    var isSelected: Bool
    var action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack {
                Image(systemName: icon)
                    .font(.system(size: 24))
                    .foregroundColor(isSelected ? .blue : .gray)
                Text(title)
                    .font(.footnote)
                    .foregroundColor(isSelected ? .blue : .gray)
            }
        }
        .padding(.vertical, 8)
    }
}

struct SampleView_Previews: PreviewProvider {
    static var previews: some View {
        SampleView()
    }
}
