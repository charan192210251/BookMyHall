import SwiftUI

struct AddHallView: View {
    @Binding var halls: [Hall]
    @State private var hallName = ""
    @State private var rating = ""
    @State private var imageName = ""
    @State private var description = ""
    @State private var location = ""
    @State private var capacity = ""
    @State private var facility = ""
    @State private var services = ""
    @State private var isLoading = false
    @State private var showAlert = false
    @State private var alertMessage = ""
    @State private var userId: Int?
    @Environment(\.presentationMode) var presentationMode
    @State private var isButtonPressed = false

    var body: some View {
        GeometryReader { geometry in
            NavigationView {
                ZStack {
                    // Background Gradient
                    LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.7), .white]),
                                   startPoint: .top, endPoint: .bottom)
                        .edgesIgnoringSafeArea(.all)

                    VStack(spacing: geometry.size.height * 0.02) { // Dynamic spacing
                        // Back Button
                        HStack {
                            Button(action: {
                                presentationMode.wrappedValue.dismiss()
                            }) {
                                Image(systemName: "chevron.left")
                                    .font(.system(size: geometry.size.width * 0.06)) // Scales with width
                                    .foregroundColor(.black)
                                    .padding()
                                    .frame(width: geometry.size.width * 0.12, height: geometry.size.width * 0.12)
                                    //.background(Color.white.opacity(0.8))
                                    .cornerRadius(geometry.size.width * 0.06)
                                   // .shadow(radius: 3)
                                    .fontWeight(.bold)
                            }
                            Spacer()
                        }
                        //.padding(.leading, geometry.size.width * 0.04)

                        // Title
                        Text("Add Hall")
                            .font(.system(size: geometry.size.width * 0.08, weight: .heavy))
                            .foregroundColor(.black)
                            .padding(.top,-40)
                        // Input Fields
                        Group {
                            inputField(placeholder: "Hall Name", text: $hallName, geometry: geometry)
                            inputField(placeholder: "Rating", text: $rating, geometry: geometry)
                            inputField(placeholder: "Image Name", text: $imageName, geometry: geometry)
                            inputField(placeholder: "Description", text: $description, geometry: geometry)
                            inputField(placeholder: "Location", text: $location, geometry: geometry)
                            inputField(placeholder: "Capacity", text: $capacity, geometry: geometry)
                            inputField(placeholder: "Facility", text: $facility, geometry: geometry)
                            inputField(placeholder: "Services", text: $services, geometry: geometry)
                        }

                        Spacer(minLength: 0) // Allows content to push dynamically

                        // Submit Button
                        if isLoading {
                            ProgressView()
                                .padding()
                        } else {
                            Button(action: {
                                isButtonPressed.toggle()
                                addHall()
                            }) {
                                Text("Submit")
                                    .frame(width: geometry.size.width * 0.6, height: geometry.size.height * 0.07)
                                    .background(Color.blue)
                                    .foregroundColor(.white)
                                    .cornerRadius(10)
                                    .shadow(radius: 3)
                                    .scaleEffect(isButtonPressed ? 0.95 : 1.0)
                                    .animation(.spring(), value: isButtonPressed)
                            }
                            .padding(.top, geometry.size.height * 0.02)

                            // Go Back to Home Button
                            NavigationLink(destination: AdminDashboardView().navigationBarBackButtonHidden(true)) {
                                Text("Go Back to Home")
                                    .frame(width: geometry.size.width * 0.6, height: geometry.size.height * 0.07)
                                    .background(Color.gray)
                                    .foregroundColor(.white)
                                    .cornerRadius(10)
                                    .shadow(radius: 3)
                                    .padding(.top, geometry.size.height * 0.01)
                            }
                        }
                    }
                    .padding()
                    .frame(width: geometry.size.width, height: geometry.size.height) // Forces to fit screen
                }
                .navigationBarHidden(true)
                .onAppear {
                    self.userId = UserDefaults.standard.integer(forKey: "user_id")
                }
                .alert(isPresented: $showAlert) {
                    Alert(title: Text("Message"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
                }
            }
        }
    }

    // TextField Helper Function (Now Fully Responsive)
    func inputField(placeholder: String, text: Binding<String>, geometry: GeometryProxy) -> some View {
        TextField(placeholder, text: text)
            .padding()
            .frame(width: geometry.size.width * 0.9, height: geometry.size.height * 0.06)
            .background(Color.white)
            .cornerRadius(10)
            .shadow(color: Color.gray.opacity(0.5), radius: 4, x: 0, y: 2)
            .padding(.horizontal)
    }

    // Add Hall Function
    func addHall() {
        if hallName.isEmpty || rating.isEmpty || imageName.isEmpty || description.isEmpty || location.isEmpty || capacity.isEmpty || facility.isEmpty || services.isEmpty {
            alertMessage = "All fields are required."
            showAlert = true
            return
        }

        isLoading = true

        let parameters: [String: String] = [
            "name": hallName,
            "rating": rating,
            "imageName": imageName,
            "description": description,
            "location": location,
            "capacity": capacity,
            "facility": facility,
            "services": services,
            "user_id": String(userId ?? 0)
        ]

        APIService.shared.sendFormDataRequest(endpoint: APIHandler.addHall, parameters: parameters) { result in
            DispatchQueue.main.async {
                self.isLoading = false
                switch result {
                case .success(let response):
                    if let success = response["success"] as? Bool, success {
                        let newHall = Hall(name: self.hallName, rating: self.rating, imageName: self.imageName)
                        self.halls.append(newHall)
                        alertMessage = "Hall added successfully."
                        showAlert = true
                        clearFields()
                    } else {
                        let message = response["message"] as? String ?? "Failed to add hall."
                        alertMessage = message.contains("already exists") ? "The hall with this name already exists." : message
                        showAlert = true
                    }
                case .failure(let error):
                    alertMessage = "Error: \(error.localizedDescription)"
                    showAlert = true
                }
            }
        }
    }

    // Clear input fields after success
    func clearFields() {
        hallName = ""
        rating = ""
        imageName = ""
        description = ""
        location = ""
        capacity = ""
        facility = ""
        services = ""
    }
}

struct AddHallView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            AddHallView(halls: .constant([]))
                .previewDevice("iPhone 16 Pro Max")
            AddHallView(halls: .constant([]))
                .previewDevice("iPhone SE (3rd generation)")
            AddHallView(halls: .constant([]))
                .previewDevice("iPhone 14")
        }
    }
}
