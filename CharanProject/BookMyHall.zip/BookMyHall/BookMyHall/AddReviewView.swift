import SwiftUI

struct AddReviewView: View {
    var hallId: Int
    var userId: Int

    @Environment(\.presentationMode) var presentationMode
    @State private var rating: Int = 0
    @State private var comment: String = ""
    @State private var isSubmitting = false
    @State private var showAlert = false
    @State private var alertMessage = ""
    @State private var isHovering = false

    var body: some View {
        ZStack {
            // Background Gradient (No Stars)
            LinearGradient(gradient: Gradient(colors: [Color(red: 0.54, green: 0.74, blue: 1), .white]),
                           startPoint: .top, endPoint: .bottom)
                .edgesIgnoringSafeArea(.all)

            VStack {
                // Header with Hover Effect
                HStack {
                    Button(action: { presentationMode.wrappedValue.dismiss() }) {
                        Image(systemName: "chevron.left")
                            .font(.system(size: 20, weight: .bold))
                            .foregroundColor(.black)
                            .padding(.leading, 8.0)
                            .scaleEffect(isHovering ? 1.1 : 1.0)
                            .animation(.easeInOut(duration: 0.2), value: isHovering)
                    }
                    .onHover { hovering in
                        isHovering = hovering
                    }

                    Spacer()

                    Text("Add Review")
                        .font(Font.custom("Roboto", size: 18).weight(.medium))
                        .foregroundColor(.black)

                    Spacer()

                    Image(systemName: "chevron.left") // Placeholder for spacing
                        .opacity(0)
                }
                .padding(.horizontal, 16)
                .frame(height: 60)
                .background(Color.white)
                .shadow(color: Color.black.opacity(0.1), radius: 4, y: 2)

                // Star Rating with Scale Effect
                Text("Rate Your Experience")
                    .font(.headline)
                    .padding(.top, 20)

                HStack {
                    ForEach(1..<6, id: \.self) { index in
                        Image(systemName: index <= rating ? "star.fill" : "star")
                            .font(.system(size: 30))
                            .foregroundColor(index <= rating ? .yellow : .gray)
                            .scaleEffect(index == rating ? 1.2 : 1.0)
                            .animation(.spring(response: 0.3, dampingFraction: 0.5), value: rating)
                            .onTapGesture {
                                rating = (rating == index) ? 0 : index  // Toggle rating selection
                            }
                    }
                }
                .padding(.top, 10)

                // Comment TextField with Transition
                TextField("Write your review...", text: $comment, axis: .vertical)
                    .padding()
                    .frame(height: 120)
                    .background(Color.white)
                    .cornerRadius(10)
                    .shadow(radius: 4)
                    .padding(.horizontal, 20)
                    .padding(.top, 20)
                    .transition(.opacity.combined(with: .slide)) // Smooth entry

                // Submit Button with Hover Effect
                Button(action: submitReview) {
                    if isSubmitting {
                        ProgressView()
                    } else {
                        Text("Submit Review")
                            .font(.system(size: 16, weight: .bold))
                            .foregroundColor(.white)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(isHovering ? Color.blue.opacity(0.8) : Color.blue)
                            .cornerRadius(10)
                            .scaleEffect(isHovering ? 1.05 : 1.0)
                            .animation(.easeInOut(duration: 0.2), value: isHovering)
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 20)
                .disabled(isSubmitting)
                .onHover { hovering in
                    isHovering = hovering
                }

                Spacer()
            }
        }
        .alert(isPresented: $showAlert) {
            Alert(title: Text("Message"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
        }
    }

    private func submitReview() {
        guard rating > 0 else {
            alertMessage = "Please select a rating."
            showAlert = true
            return
        }
        guard !comment.isEmpty else {
            alertMessage = "Please enter a comment."
            showAlert = true
            return
        }

        isSubmitting = true
        let parameters: [String: String] = [
            "hall_id": "\(hallId)",
            "user_id": "\(userId)",
            "rating": "\(rating)",
            "comment": comment
        ]

        APIService.shared.sendFormDataRequest(endpoint: APIHandler.reviews, parameters: parameters) { result in
            DispatchQueue.main.async {
                isSubmitting = false
                switch result {
                case .success(let response):
                    if let status = response["status"] as? Bool, status {
                        alertMessage = (response["message"] as? String) ?? "Review submitted successfully!"
                        showAlert = true
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                            presentationMode.wrappedValue.dismiss()
                        }
                    } else {
                        alertMessage = (response["message"] as? String) ?? "Failed to submit review."
                        showAlert = true
                    }
                case .failure(let error):
                    alertMessage = error.localizedDescription
                    showAlert = true
                }
            }
        }
    }
}

// Preview
struct AddReviewView_Previews: PreviewProvider {
    static var previews: some View {
        AddReviewView(hallId: 1, userId: 1)
    }
}
