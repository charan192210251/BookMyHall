import SwiftUI

struct HallView: View {
    @Binding var selectedTab: SampleView.Tab
    @Binding var showTabBar: Bool
    @State private var halls: [Hall] = []
    @State private var searchText = ""
    @State private var isLoading = false
    @State private var errorMessage: String?
    @Environment(\.presentationMode) var presentationMode
    
    var filteredHalls: [Hall] {
        searchText.isEmpty ? halls : halls.filter { $0.name.lowercased().contains(searchText.lowercased()) }
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                LinearGradient(
                    gradient: Gradient(colors: [Color.blue.opacity(0.7), .white]),
                    startPoint: .top,
                    endPoint: .bottom
                )
                .edgesIgnoringSafeArea(.all)
                
                VStack {
                    HStack {
//                        Button(action: {
//                            presentationMode.wrappedValue.dismiss()
//                        }) {
//                            Image(systemName: "chevron.left")
//                                .font(.system(size: 20, weight: .medium))
//                                .foregroundColor(.black)
//                                .padding()
//                        }
//                        .frame(width: 40, height: 40)
                        
                        Text("Celebrate In Style")
                            .font(.headline)
                            .foregroundColor(.black)
                            .padding(.leading,110)
                        Spacer()
                        
                        
                    }
                    .padding()
                    .background(Color.white)
                    
                    
                    HStack {
                        Image(systemName: "magnifyingglass")
                            .foregroundColor(.blue)
                            .padding(.leading, 10)
                        
                        TextField("Search Halls", text: $searchText)
                            .padding()
                            .background(Color.white)
                            .cornerRadius(8)
                    }
                    .frame(height: 50)
                    .background(Color.white)
                    .cornerRadius(24)
                    .shadow(radius: 5)
                    .padding(.horizontal, 20)
                    
                    if isLoading {
                        ProgressView()
                            .padding()
                    } else if let errorMessage = errorMessage {
                        Text(errorMessage)
                            .foregroundColor(.red)
                            .padding()
                    } else {
                        ScrollView {
                            VStack(spacing: 15) {
                                ForEach(filteredHalls) { hall in
                                        NavigationLink(destination: MccView(selectedHall: hall).navigationBarBackButtonHidden(true)) {
                                            EventCardView(hall: hall)
                                                .frame(width: 350, height: 100)
                                        }
                                        .buttonStyle(PlainButtonStyle())
                                }
                            }
                            .padding(.top, 10)
                        }
                    }
                    Spacer()
                }
            }
            .navigationBarHidden(true)
            .onAppear {
                fetchHalls()
            }
        }
    }
    
    func fetchHalls() {
        isLoading = true
        errorMessage = nil
        
        APIService.shared.sendFormDataRequest(endpoint: APIHandler.fetchHalls, parameters: [:]) { result in
            DispatchQueue.main.async {
                isLoading = false
                switch result {
                case .success(let json):
                    if let data = json["halls"] as? [[String: Any]] {
                        halls = data.compactMap { dict in
                            guard let id = dict["id"] as? String,
                                  let name = dict["name"] as? String,
                                  let rating = dict["rating"] as? String,
                                  let imageName = dict["imageName"] as? String,
                                  let description = dict["description"] as? String,
                                  let location = dict["location"] as? String,
                                  let capacity = dict["capacity"] as? String,
                                  let facility = dict["facility"] as? String,
                                  let services = dict["services"] as? String,
                                  let availability = dict["availability"] as? String else { return nil }
                            
                            return Hall(id: id, name: name, rating: rating, imageName: imageName, description: description, location: location, capacity: capacity, facility: facility, services: services, availability: availability)
                        }
                    } else {
                        errorMessage = "Failed to load halls."
                    }
                case .failure(let error):
                    errorMessage = "Error: \(error.localizedDescription)"
                }
            }
        }
    }

}

struct EventCardView: View {
    var hall: Hall
    
    var body: some View {
        VStack {
            HStack {
                if let imageURL = URL(string: hall.imageName), hall.imageName.contains("http") {
                    AsyncImage(url: imageURL) { image in
                        image.resizable().scaledToFit()
                    } placeholder: {
                        ProgressView()
                    }
                    .frame(width: 60, height: 60)
                    .cornerRadius(10)
                    .shadow(radius: 10)
                } else {
                    Image(hall.imageName)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 60, height: 60)
                        .cornerRadius(10)
                        .shadow(radius: 10)
                }
                
                VStack(alignment: .leading, spacing: 5) {
                    Text(hall.name)
                        .font(.headline)
                        .foregroundColor(.black)
                    
                    // ⭐ Rating with Gold Star
                    HStack {
                        Image(systemName: "star.fill")
                            .foregroundColor(.yellow) // Gold star
                        Text(hall.rating)
                            .font(.subheadline)
                            .foregroundColor(Color.gray)
                    }

                    // Availability
                    HStack {
                        Text("Availability : ")
                            .fontWeight(.medium)
                        if hall.availability == "yes" {
                            Text(hall.availability ?? "No Data")
                                .textCase(.uppercase)
                                .foregroundStyle(.green)
                        } else {
                            Text(hall.availability ?? "No Data")
                                .textCase(.uppercase)
                                .foregroundStyle(.red)
                        }
                    }
                    .font(.custom("Roboto-Medium", size: 16))
                }
                Spacer()
                
            }
            .padding()
            .background(Color(#colorLiteral(red: 0.8156862745, green: 0.9490196078, blue: 0.9921568627, alpha: 1)))
            .cornerRadius(10)
            .shadow(radius: 5)
        }
        .padding(.horizontal)
    }
}


struct Hall: Identifiable {
    var id: String?
    var name: String
    var rating: String
    var imageName: String
    var description: String?
    var location: String?
    var capacity: String?
    var facility: String?
    var services: String?
    var availability: String?
    
}



struct HallView_Previews: PreviewProvider {
    static var previews: some View {
        HallView(
            selectedTab: .constant(.home),
            showTabBar: .constant(true)
        )
    }
}
