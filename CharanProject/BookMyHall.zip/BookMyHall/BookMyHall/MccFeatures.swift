import SwiftUI

struct MccFeatures: View {
    var selectedHall: Hall
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        GeometryReader { geometry in
            NavigationView {
                ScrollView {
                    VStack {
                        // Top Bar
                        HStack {
                            Button(action: {
                                presentationMode.wrappedValue.dismiss()
                            }) {
                                Image(systemName: "chevron.left")
                                    .font(.system(size: 20, weight: .medium))
                                    .foregroundColor(.black)
                                    .fontWeight(.bold)
                                    .padding()
                            }
                            .offset(x:20,y:20)
                            Spacer()
                            Text("FEATURES")
                                .font(Font.custom("Roboto", size: 16).weight(.semibold))
                                .foregroundColor(.black)
                                .offset(x:-25,y:25)
                            Spacer()
                        }
                        .frame(width:440,height:90)
                        //.padding(.top,-40)
                        .background(Color.white)
                        
                        Text(selectedHall.name)
                            .font(Font.custom("Roboto", size: 20))
                            .foregroundColor(.black)
                            .padding(.top, 10)
                        
                        // Description
                        RoundedRectangle(cornerRadius: 20.96)
                            .fill(Color(red: 0.88, green: 0.93, blue: 0.98))
                            .frame(width: geometry.size.width * 0.9, height: 100)
                            .shadow(radius: 10)
                            .overlay(
                                Text(selectedHall.description ?? "")
                                    .font(Font.custom("Roboto", size: 16))
                                    .foregroundColor(Color.gray)
                                    .padding()
                            )
                        
                        // Location Section
                        FeatureCard(icon: "locationIcon", title: "LOCATION", value: selectedHall.location ?? "", bgColor: .gray, textColor: .white)
                        
                        // Capacity Section (Light Green)
                        FeatureCard(icon: "capacityIcon", title: "CAPACITY", value: selectedHall.capacity ?? "", bgColor: Color(red: 113/255, green: 247/255, blue: 250/255))
                        
                        // Facility Section (Light Orange)
                        FeatureCard(icon: "facilityIcon", title: "FACILITY", value: selectedHall.facility ?? "", bgColor: Color.orange.opacity(0.3))
                        
                        // Services Section (Light Violet)
                        FeatureCard(icon: "servicesIcon", title: "SERVICES", value: selectedHall.services ?? "", bgColor: Color.purple.opacity(0.3))
                        
                        // Book Now Button
                        NavigationLink(destination: DateView(selectedHall: selectedHall).navigationBarBackButtonHidden(true)) {
                            Text("Book Now")
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.green)
                                .foregroundColor(.white)
                                .cornerRadius(15)
                                .shadow(radius: 10)
                        }
                        
                        .padding(.horizontal,90)
                    }
                    .padding(.top,-69)
                }
                .background(
                    LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.5), .white]), startPoint: .top, endPoint: .bottom)
                        .edgesIgnoringSafeArea(.all)
                )
            }
        }
    }
}

struct FeatureCard: View {
    var icon: String
    var title: String
    var value: String
    var bgColor: Color
    var textColor: Color = .black
    
    var body: some View {
        RoundedRectangle(cornerRadius: 20.96)
            .fill(bgColor)
            .frame(width: UIScreen.main.bounds.width * 0.9, height: 100)
            .shadow(radius: 10)
            .overlay(
                HStack {
                    Image(icon)
                        .resizable()
                        .frame(width: 40, height: 40)
                    VStack(alignment: .leading) {
                        Text(title)
                            .font(Font.custom("Roboto", size: 16).weight(.semibold))
                            .foregroundColor(textColor)
                        Text(value)
                            .font(Font.custom("Roboto", size:14))
                            .foregroundColor(textColor.opacity(0.8))
                    }
                    Spacer()
                }
                .padding()
            )
            .padding(.vertical, 5)
    }
}

struct MccFeatures_Previews: PreviewProvider {
    static var previews: some View {
        MccFeatures(selectedHall: Hall(name: "Sample Hall", rating: "", imageName: "", location: "Sample Location"))
    }
}
