import SwiftUI

struct MainView: View {
    @Binding var selectedTab: SampleView.Tab
    @Binding var showTabBar: Bool

    var body: some View {
        NavigationView {
            ZStack {
                LinearGradient(gradient: Gradient(colors: [Color(red: 0.54, green: 0.74, blue: 1), .white]), startPoint: .top, endPoint: .bottom)
                    .edgesIgnoringSafeArea(.all)
                
                VStack(spacing: 15) {
                    // TOP BAR
                    HStack {
                        NavigationLink(destination: MainMenuView(showTabBar: $showTabBar).navigationBarBackButtonHidden(true)) {
                            Image(systemName: "line.horizontal.3")
                                .resizable()
                                .frame(width: 22, height: 15)
                                .foregroundColor(.black)
                        }
                        Spacer()
                        
                        Text("BookMyHall")
                            .font(Font.custom("Roboto", size: 20).weight(.bold))
                            .foregroundColor(.black)
                        
                        Spacer()
                    }
                    .padding()
                    .frame(maxWidth: .infinity, maxHeight: 60)
                    .background(Color.white)
                    .padding(.top, -20)
                    
                    // EVENT CATEGORIES
                    Text("Event Categories")
                        .font(Font.custom("Roboto", size: 22).weight(.bold))
                        .foregroundColor(.black)
                        .padding(.top, 5)

                    // GRID WITHOUT SCROLLVIEW
                    LazyVGrid(columns: [
                        GridItem(.flexible(), spacing: 20),
                        GridItem(.flexible(), spacing: 20)
                    ], spacing: 20) {
                        EventCard(color: Color(red: 0.94, green: 0.67, blue: 0.35), imageName: "marriageLogo", text: "Marriage")
                            .onTapGesture { selectedTab = .search }
                        
                        EventCard(color: Color(red: 0.35, green: 0.94, blue: 0.68), imageName: "birthdayLogo", text: "Birthday")
                            .onTapGesture { selectedTab = .search }
                        
                        EventCard(color: Color(red: 0.94, green: 0.35, blue: 0.69), imageName: "functionLogo", text: "Functions")
                            .onTapGesture { selectedTab = .search }
                        
                        EventCard(color: Color(red: 0.28, green: 0.74, blue: 0.81), imageName: "eventLogo", text: "Cultural Events")
                            .onTapGesture { selectedTab = .search }
                    }
                    .padding(.horizontal, 15)
                    
                    Spacer()  // Pushes content upwards to avoid centering everything
                }
            }
            .navigationViewStyle(StackNavigationViewStyle())
            .navigationBarHidden(true)
            .onAppear {
                showTabBar = true
            }
        }
    }
}

struct EventCard: View {
    var color: Color
    var imageName: String
    var text: String

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 15)
                .fill(color)
                .frame(height: 180)
                .shadow(color: Color.black.opacity(0.2), radius: 5, x: 0, y: 5)

            VStack {
                Image(imageName)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 90, height: 90)
                    .shadow(color: Color.gray.opacity(0.2), radius: 5, y: 4)

                Text(text)
                    .font(Font.custom("Roboto", size: 16).weight(.medium))
                    .foregroundColor(.white)
            }
        }
    }
}

struct MainView_Previews: PreviewProvider {
    static var previews: some View {
        MainView(selectedTab: .constant(.home), showTabBar: .constant(true))
    }
}
