import SwiftUI

struct SuccessSignupView: View {
    var body: some View {
        NavigationView {
            ZStack {
                // Background Gradient
                LinearGradient(
                    gradient: Gradient(colors: [Color.blue.opacity(0.7), .white]),
                    startPoint: .top,
                    endPoint: .bottom
                )
                .edgesIgnoringSafeArea(.all)

                VStack(spacing: 20) {
                    // App Logo from Assets
                    Image("mainLogo") // Replace with your logo
                        .resizable()
                        .scaledToFit()
                        .frame(width: 100, height: 100) // Adjusted size
                        .shadow(color: Color.gray.opacity(0.5), radius: 5, y: 4)
                        .padding(.top, 50)

                    // Title
                    Text("BookMyHall")
                        .font(.custom("Roboto", size: 24))
                        .fontWeight(.semibold)
                        .foregroundColor(.black)

                    // Green Tick Logo (you can add your own tick image)
                    Image("tickLogo") // Replace with your green tick logo
                        .resizable()
                        .scaledToFit()
                        .frame(width: 60, height: 60) // Adjust the size as needed
                        .padding(.top, 20)

                    // Success message
                    Text("Congratulations!")
                        .font(.title)
                        .fontWeight(.bold)
                        .foregroundColor(.black)

                    Text("You have successfully signed up.")
                        .font(.custom("Roboto", size: 18))
                        .foregroundColor(.black)
                        .padding(.top, 10)

                    Text("Login to continue")
                        .font(.custom("Roboto", size: 18))
                        .foregroundColor(.black)
                        .padding(.top, 10)

                    Spacer().frame(height: 20)

                    // Log In Button (Navigating to LoginView)
                    NavigationLink(destination: LoginView(showTabBar: .constant(true)).navigationBarBackButtonHidden(true)) {
                        Text("Go to Login")
                            .font(.custom("Roboto", size: 18))
                            .fontWeight(.medium)
                            .foregroundColor(.white)
                            .frame(width: 250, height: 50)
                            .background(Color.black)
                            .cornerRadius(6)
                            .shadow(color: Color.gray.opacity(0.5), radius: 5, y: 4)
                            .padding(.top, 20)
                    }

                    Spacer(minLength: 60) // Adds space at the bottom
                }
                .padding()
                .frame(maxHeight: .infinity, alignment: .top) // Keeps content aligned at the top
            }
        }
    }
}

// Preview
struct SuccessSignupView_Previews: PreviewProvider {
    static var previews: some View {
        SuccessSignupView()
            .previewDevice("iPhone 16 Pro")
    }
}
