import Foundation

class APIService {
    static let shared = APIService()

    // MARK: - Send Form Data Request (For Non-Image Data)
    func sendFormDataRequest(endpoint: String, parameters: [String: String], completion: @escaping (Result<[String: Any], Error>) -> Void) {
        guard let url = URL(string: endpoint) else {
            completion(.failure(NSError(domain: "Invalid URL", code: 400, userInfo: nil)))
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        let boundary = "Boundary-\(UUID().uuidString)"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")

        print("📌 [DEBUG] Sending FormData Request to: \(url)")
        print("📌 [DEBUG] Parameters: \(parameters)")

        let body = createMultipartBody(parameters: parameters, boundary: boundary)
        request.httpBody = body

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }

            guard let data = data else {
                completion(.failure(NSError(domain: "No data received", code: 500, userInfo: nil)))
                return
            }

            do {
                let jsonResponse = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
                print("✅ [DEBUG] JSON Response: \(jsonResponse ?? [:])")
                completion(.success(jsonResponse ?? [:]))
            } catch {
                completion(.failure(error))
            }
        }.resume()
    }

    // MARK: - Upload Multiple Images (For Image Uploading)
    func uploadMultipleImages(endpoint: String, parameters: [String: String], imagesData: [Data], completion: @escaping (Result<[String: Any], Error>) -> Void) {
        guard let url = URL(string: endpoint) else {
            completion(.failure(NSError(domain: "Invalid URL", code: 400, userInfo: nil)))
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        let boundary = "Boundary-\(UUID().uuidString)"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")

        print("📌 [DEBUG] Uploading Images to: \(endpoint)")
        print("📌 [DEBUG] Request Headers: \(request.allHTTPHeaderFields ?? [:])")

        var body = createMultipartBody(parameters: parameters, boundary: boundary)

        // Adding images to the request body
        for (index, imageData) in imagesData.enumerated() {
            let filename = "image\(index).jpg"
            let mimeType = "image/jpeg"
            let fieldName = "images[]"

            body.append("--\(boundary)\r\n".data(using: .utf8)!)
            body.append("Content-Disposition: form-data; name=\"\(fieldName)\"; filename=\"\(filename)\"\r\n".data(using: .utf8)!)
            body.append("Content-Type: \(mimeType)\r\n\r\n".data(using: .utf8)!)
            body.append(imageData)
            body.append("\r\n".data(using: .utf8)!)
        }

        body.append("--\(boundary)--\r\n".data(using: .utf8)!)
        request.httpBody = body

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("❌ [DEBUG] Error: \(error.localizedDescription)")
                completion(.failure(error))
                return
            }

            if let httpResponse = response as? HTTPURLResponse {
                print("📌 [DEBUG] Response Status Code: \(httpResponse.statusCode)")
            }

            guard let data = data else {
                print("❌ [DEBUG] No data received from server")
                completion(.failure(NSError(domain: "No data received", code: 500, userInfo: nil)))
                return
            }

            // Print Raw Response
            if let rawResponse = String(data: data, encoding: .utf8) {
                print("📌 [DEBUG] Raw Response: \(rawResponse)")
            }

            // Decode JSON
            do {
                let jsonResponse = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
                print("✅ [DEBUG] JSON Response: \(jsonResponse ?? [:])")
                completion(.success(jsonResponse ?? [:]))
            } catch {
                print("❌ [DEBUG] JSON Parsing Error: \(error.localizedDescription)")
                completion(.failure(error))
            }
        }.resume()
    }

    // MARK: - Create Multipart Form Data Body (Reused for both functions)
    private func createMultipartBody(parameters: [String: String], boundary: String) -> Data {
        var body = Data()
        for (key, value) in parameters {
            body.append("--\(boundary)\r\n".data(using: .utf8)!)
            body.append("Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".data(using: .utf8)!)
            body.append("\(value)\r\n".data(using: .utf8)!)
        }
        body.append("--\(boundary)--\r\n".data(using: .utf8)!)
        return body
    }
}
