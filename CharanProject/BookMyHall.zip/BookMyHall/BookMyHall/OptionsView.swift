import SwiftUI
import PhotosUI

struct OptionsView: View {
    var hall: Hall
    
    @State private var selectedItem: PhotosPickerItem? // Store selected photo item
    @State private var selectedImages: [UIImage] = [] // Store selected images
    @State private var isImageSelected: Bool = false // Check if image is selected
    @State private var isLoading: Bool = false
    @State private var errorMessage: String?
    @Environment(\.presentationMode) var presentationMode

    // Image upload function
    func uploadImage() {
        guard let image = selectedImages.first else { return }

        isLoading = true
        // Convert image to data
        if let imageData = image.jpegData(compressionQuality: 0.7) {
            // Ensure hall.id is unwrapped to a non-optional String
            let parameters: [String: String] = [
                "hall_id": hall.id ?? "" // Unwrap hall.id safely
            ]
            
            let endpoint = APIHandler.uploadImages // Use the correct endpoint
            
            APIService.shared.sendFormDataRequest(endpoint: endpoint, parameters: parameters) { result in
                DispatchQueue.main.async {
                    isLoading = false
                    switch result {
                    case .success(let response):
                        print("Image uploaded successfully: \(response)")
                        // Handle success (maybe show a confirmation message)
                    case .failure(let error):
                        errorMessage = error.localizedDescription
                    }
                }
            }
        }
    }

    var body: some View {
        ZStack {
            // Gradient Background
            LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.7), .white]),
                           startPoint: .top, endPoint: .bottom)
                .edgesIgnoringSafeArea(.all)

            VStack {
                // Back Button
                Button(action: {
                    // Close the current view
                    self.presentationMode.wrappedValue.dismiss()
                }) {
                    Image(systemName: "chevron.left")
                        .font(.system(size: 20, weight: .medium))
                        .foregroundColor(.black)
                        .fontWeight(.bold)
                        .padding()
                        .frame(width: 40, height: 40)
                        .background(Color.clear)
                        .cornerRadius(20)
                }
                .offset(x: -168, y: 60)

                Text("Upload Images for \(hall.name)")
                    .font(.largeTitle)
                    .fontWeight(.heavy)
                    .foregroundColor(.black)

                if isLoading {
                    ProgressView("Uploading...")
                        .progressViewStyle(CircularProgressViewStyle(tint: .black))
                        .padding()
                } else if let errorMessage = errorMessage {
                    Text(errorMessage)
                        .foregroundColor(.red)
                        .multilineTextAlignment(.center)
                        .padding()
                }

                Spacer()

                // Select Image Button using PhotosPicker
                PhotosPicker(
                    selection: $selectedItem,
                    matching: .images,
                    photoLibrary: .shared()) {
                        Text("Select Image")
                            .font(.headline)
                            .foregroundColor(.white)
                            .padding()
                            .background(Color.blue)
                            .cornerRadius(10)
                    }
                    .onChange(of: selectedItem) { newItem in
                        Task {
                            // Retrieve selected image data
                            if let selectedItem = newItem {
                                // Get the selected image as UIImage
                                if let data = try? await selectedItem.loadTransferable(type: Data.self),
                                   let uiImage = UIImage(data: data) {
                                    selectedImages = [uiImage]
                                    isImageSelected = true
                                }
                            }
                        }
                    }
                    .padding()

                // Display Selected Image
                if isImageSelected, let firstImage = selectedImages.first {
                    Image(uiImage: firstImage)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 250, height: 250)
                        .cornerRadius(10)
                        .padding()
                }

                // Upload Button
                Button(action: {
                    uploadImage()
                }) {
                    Text("Upload Image")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .background(selectedImages.isEmpty ? Color.gray : Color.blue)
                        .cornerRadius(10)
                }
                .padding()
                .disabled(selectedImages.isEmpty) // Disable upload button if no image is selected

                Spacer()
            }
            .padding(.top, -40)
        }
    }
}

struct OptionsView_Previews: PreviewProvider {
    static var previews: some View {
        OptionsView(hall: Hall(id: "1", name: "Sample Hall", rating: "4.6", imageName: "sample.jpg"))
    }
}
