import SwiftUI

struct UpdateHallDetailsView: View {
    @State var hall: Hall
    @State private var isLoading = false
    @State private var alertMessage = ""
    @State private var showAlert = false
    @State private var isButtonPressed = false
    @Environment(\.presentationMode) var presentationMode

    init(hall: Hall) {
        _hall = State(initialValue: hall)
    }

    var body: some View {
        GeometryReader { geometry in
            NavigationView {
                ZStack {
                    LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.7), .white]),
                                   startPoint: .top, endPoint: .bottom)
                        .edgesIgnoringSafeArea(.all)
                    
                    VStack(spacing: geometry.size.height * 0.02) {
                        // Back Button
                        HStack {
                            Button(action: {
                                presentationMode.wrappedValue.dismiss()
                            }) {
                                Image(systemName: "chevron.left")
                                    .font(.system(size: geometry.size.width * 0.06))
                                    .foregroundColor(.black)
                                    .padding()
                                    .frame(width: geometry.size.width * 0.12, height: geometry.size.width * 0.12)
                                    .cornerRadius(geometry.size.width * 0.06)
                                    .fontWeight(.bold)
                            }
                            Spacer()
                        }

                        // Title
                        Text("Update Hall")
                            .font(.system(size: geometry.size.width * 0.08, weight: .heavy))
                            .foregroundColor(.black)
                            .padding(.top, -40)

                        // Input Fields
                        Group {
                            inputField(placeholder: "Hall Name", text: $hall.name, geometry: geometry)
                            inputField(placeholder: "Rating", text: $hall.rating, geometry: geometry)
                            inputField(placeholder: "Image Name", text: $hall.imageName, geometry: geometry)
                            inputField(placeholder: "Description", text: Binding(get: { hall.description ?? "" }, set: { hall.description = $0 }), geometry: geometry)
                            inputField(placeholder: "Location", text: Binding(get: { hall.location ?? "" }, set: { hall.location = $0 }), geometry: geometry)
                            inputField(placeholder: "Capacity", text: Binding(get: { hall.capacity ?? "" }, set: { hall.capacity = $0 }), geometry: geometry)
                            inputField(placeholder: "Facility", text: Binding(get: { hall.facility ?? "" }, set: { hall.facility = $0 }), geometry: geometry)
                            inputField(placeholder: "Services", text: Binding(get: { hall.services ?? "" }, set: { hall.services = $0 }), geometry: geometry)
                        }

                        Spacer()

                        // Submit Button
                        if isLoading {
                            ProgressView()
                                .padding()
                        } else {
                            Button(action: {
                                isButtonPressed.toggle()
                                updateHall()
                            }) {
                                Text("Update")
                                    .frame(width: geometry.size.width * 0.6, height: geometry.size.height * 0.07)
                                    .background(Color.blue)
                                    .foregroundColor(.white)
                                    .cornerRadius(10)
                                    .shadow(radius: 3)
                                    .scaleEffect(isButtonPressed ? 0.95 : 1.0)
                                    .animation(.spring(), value: isButtonPressed)
                            }
                            .padding(.top,-70)
                        }
                    }
                    .padding()
                    .frame(width: geometry.size.width, height: geometry.size.height)
                }
                .navigationBarHidden(true)
                .alert(isPresented: $showAlert) {
                    Alert(title: Text("Message"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
                }
            }
        }
    }

    // TextField Helper Function
    func inputField(placeholder: String, text: Binding<String>, geometry: GeometryProxy) -> some View {
        TextField(placeholder, text: text)
            .padding()
            .frame(width: geometry.size.width * 0.9, height: geometry.size.height * 0.06)
            .background(Color.white)
            .cornerRadius(10)
            .shadow(color: Color.gray.opacity(0.5), radius: 4, x: 0, y: 2)
            .padding(.horizontal)
    }

    // Update Hall Function
    func updateHall() {
        if hall.name.isEmpty || hall.rating.isEmpty || hall.imageName.isEmpty || hall.description?.isEmpty ?? true || hall.location?.isEmpty ?? true || hall.capacity?.isEmpty ?? true || hall.facility?.isEmpty ?? true || hall.services?.isEmpty ?? true {
            alertMessage = "All fields are required."
            showAlert = true
            return
        }

        isLoading = true

        let parameters: [String: String] = [
            "hall_id": hall.id ?? "",
            "name": hall.name,
            "rating": hall.rating,
            "imageName": hall.imageName,
            "description": hall.description ?? "",
            "location": hall.location ?? "",
            "capacity": hall.capacity ?? "",
            "facility": hall.facility ?? "",
            "services": hall.services ?? ""
        ]

        APIService.shared.sendFormDataRequest(endpoint: APIHandler.updateHall, parameters: parameters) { result in
            DispatchQueue.main.async {
                self.isLoading = false
                switch result {
                case .success(let response):
                    if let success = response["success"] as? Bool, success {
                        alertMessage = "Hall updated successfully."
                        showAlert = true
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                            self.presentationMode.wrappedValue.dismiss()
                        }
                    } else {
                        let message = response["message"] as? String ?? "Failed to update hall."
                        alertMessage = message
                        showAlert = true
                    }
                case .failure(let error):
                    alertMessage = "Error: \(error.localizedDescription)"
                    showAlert = true
                }
            }
        }
    }
}

struct UpdateHallDetailsView_Previews: PreviewProvider {
    static var previews: some View {
        UpdateHallDetailsView(hall: Hall(id: "1", name: "Grand Hall", rating: "5", imageName: "image_url", description: "Spacious hall", location: "New York", capacity: "500", facility: "AC, WiFi", services: "Catering", availability: "Available"))
    }
}
