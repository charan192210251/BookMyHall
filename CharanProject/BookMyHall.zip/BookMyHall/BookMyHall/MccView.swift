import SwiftUI

struct MccView: View {
    var selectedHall: Hall
    @Environment(\.presentationMode) var presentationMode

    var body: some View {
        NavigationView {
            GeometryReader { geometry in
                ZStack {
                    LinearGradient(gradient: Gradient(colors: [Color(red: 0.54, green: 0.74, blue: 1), .white]), startPoint: .top, endPoint: .bottom)
                        .edgesIgnoringSafeArea(.all)
                    
                    VStack(spacing: 0) {
                        HStack {
                            Button(action: {
                                presentationMode.wrappedValue.dismiss()
                            }) {
                                Image(systemName: "chevron.left")
                                    .font(.system(size: 20, weight: .bold))
                                    .foregroundColor(.black)
                                    .padding(.leading, 16)
                            }
                            Spacer()
                            Text(selectedHall.name)
                                .font(Font.custom("Roboto", size: 16).weight(.semibold))
                                .foregroundColor(.black)
                                .offset(x: -15)
                            Spacer()
                        }
                        .frame(width: geometry.size.width, height: 50)
                        .background(Color.white)
                        
                        VStack(spacing: 15) {
                            customButton(title: "Pictures", destination: MccPictures(selectedHall: selectedHall))
                            customButton(title: "Features", destination: MccFeatures(selectedHall: selectedHall))
                            customButton(title: "Reviews", destination: MccReviews(selectedHall: selectedHall))
                        }
                        .padding(.top, 28)
                        
                        // First text
                        Text("Contact hall owner for price details before booking the hall")
                            .font(Font.custom("Roboto", size: 18).weight(.medium))
                            .foregroundColor(.black)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 20)
                            .padding(.vertical, 70)
                        
                        // Second text added here
                        Text("Go to Features for Contact Number")
                            .font(Font.custom("Roboto", size: 16).weight(.regular))
                            .foregroundColor(.gray)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 20)
                            .padding(.vertical, 5) // Small padding to separate it from the first text
                        
                        NavigationLink(destination: DateView(selectedHall: selectedHall).navigationBarBackButtonHidden(true)) {
                            ZStack {
                                Rectangle()
                                    .foregroundColor(.black)
                                    .frame(width: geometry.size.width * 0.55, height: 50)
                                    .cornerRadius(10)
                                    .shadow(color: Color.gray.opacity(0.5), radius: 20, y: 4)
                                Text("BOOK HERE")
                                    .font(Font.custom("Roboto", size: 18).weight(.medium))
                                    .foregroundColor(.white)
                                    .frame(width: geometry.size.width * 0.55)
                                    .multilineTextAlignment(.center)
                            }
                        }
                        .padding(.top, 20)
                        
                        Spacer()
                    }
                    .frame(width: geometry.size.width, height: geometry.size.height)
                }
            }
        }
    }
    
    private func customButton<Destination: View>(title: String, destination: Destination) -> some View {
        NavigationLink(destination: destination.navigationBarBackButtonHidden(true)) {
            Text(title)
                .font(Font.custom("Roboto", size: 18).weight(.bold))
                .foregroundColor(.white)
                .frame(width: 200, height: 50)
                .background(Color.blue)
                .cornerRadius(12)
                .shadow(radius: 5)
        }
    }
}

struct MccView_Previews: PreviewProvider {
    static var previews: some View {
        MccView(selectedHall: Hall(name: "MCC Marriage Hall", rating: "4.6 (814 reviews)", imageName: "mccMain"))
    }
}
