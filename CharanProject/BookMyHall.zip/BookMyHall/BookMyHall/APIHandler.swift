//
//  APIHandler.swift
//  BookMyHall
//
//  Created by SAIL on 06/02/25.
//

struct APIHandler
{
    static let baseURL = "http://localhost/BookMyHall/"
    static let login = baseURL + "login.php"
    static let register = baseURL + "register.php"
    static let createHall = baseURL + "createHall.php"
    static let updateHall = baseURL + "updateHall.php"
    static let deleteHall = baseURL + "deleteHall.php"
    static let showProfile = baseURL + "showProfile.php"
    static let editProfile = baseURL + "editProfile.php"
    static let addHall = baseURL + "addHall.php"
    static let fetchHalls = baseURL + "fetchHalls.php"
    static let forgotPassword = baseURL + "forgotPassword.php"
    static let changePassword = baseURL + "changePassword.php"
    static let resetPassword = baseURL + "resetPassword.php"
    static let reviews = baseURL + "reviews.php"
    static let fetchReviews = baseURL + "fetchReviews.php"
    static let uploadImages = baseURL + "uploadImages.php"
    static let fetchBookings = baseURL + "fetchBookings.php"
    static let saveBooking = baseURL + "saveBooking.php"
    static let checkAvailability = baseURL + "checkAvailability.php"
    static let updateBooking = baseURL + "updateBooking.php"
    static let contactus = baseURL + "contactus.php"
    static let fetchImages = baseURL + "fetchImages.php"
    static let deleteBooking = baseURL + "deleteBooking.php"
    static let deleteReview = baseURL + "deleteReview.php"
}
