import SwiftUI

struct LoginView: View {
    @State private var email: String = "test1@gmail.com"
    @State private var password: String = "1"
    @Binding var showTabBar: Bool
    @State private var errorMessage: String?
    @State private var isLoginSuccessful = false
    @State private var isAdmin = false
    @State private var isLoading = false
    @State private var isPasswordVisible = false
    @State private var showAlert = false  // ✅ Controls the alert popup

    var body: some View {
        NavigationStack {
            ZStack {
                LinearGradient(
                    gradient: Gradient(colors: [Color.blue.opacity(0.7), .white]),
                    startPoint: .top,
                    endPoint: .bottom
                )
                .edgesIgnoringSafeArea(.all)

                VStack {
                    Image("mainLogo")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 100, height: 100)
                        .shadow(color: Color.gray.opacity(0.5), radius: 10, y: 4)

                    Image("loginLogo")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 50, height: 80)
                        .shadow(color: Color.gray.opacity(0.5), radius: 10, y: 4)

                    Text("Login")
                        .font(.largeTitle)
                        .fontWeight(.heavy)
                        .tracking(1.28)
                        .foregroundColor(Color.black.opacity(0.8))

                    VStack(alignment: .leading, spacing: 15) {
                        Text("Email")
                            .font(.custom("Roboto", size: 18))
                            .foregroundColor(.black)

                        TextField("Enter your email", text: $email)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled(true)
                            .padding()
                            .frame(height: 50)
                            .background(Color.white.opacity(0.8))
                            .cornerRadius(6)
                            .shadow(color: Color.gray.opacity(0.2), radius: 4, y: 2)
                            .onChange(of: email) { newValue in
                                email = newValue.lowercased()
                            }

                        Text("Password")
                            .font(.custom("Roboto", size: 18))
                            .foregroundColor(.black)

                        HStack {
                            if isPasswordVisible {
                                TextField("Enter your password", text: $password)
                            } else {
                                SecureField("Enter your password", text: $password)
                            }

                            Button(action: { isPasswordVisible.toggle() }) {
                                Image(systemName: isPasswordVisible ? "eye.slash" : "eye")
                                    .foregroundColor(.black)
                                    .padding(.trailing, 10)
                            }
                        }
                        .padding()
                        .frame(height: 50)
                        .background(Color.white.opacity(0.8))
                        .cornerRadius(6)
                        .shadow(color: Color.gray.opacity(0.2), radius: 4, y: 2)

                        HStack {
                            Spacer()
                            NavigationLink(destination: ForgotPasswordView().navigationBarBackButtonHidden(true)) {
                                Text("Forgot?")
                                    .font(.custom("Roboto", size: 18))
                                    .foregroundColor(.gray)
                            }
                        }
                    }
                    .padding(.horizontal, 40)

                    if isLoading {
                        ProgressView()
                            .padding()
                    } else {
                        Button(action: loginUser) {
                            Text("Log In")
                                .font(.custom("Roboto", size: 18))
                                .fontWeight(.medium)
                                .foregroundColor(.white)
                                .frame(width: 298, height: 50)
                                .background(Color.black)
                                .cornerRadius(6)
                                .shadow(color: Color.gray.opacity(0.5), radius: 10, y: 4)
                        }
                        .padding(.top, 20)
                    }

                    HStack {
                        Text("Don’t have an account? ")
                            .font(.custom("Roboto", size: 16))
                            .foregroundColor(.black)

                        NavigationLink(destination: SignupView().navigationBarBackButtonHidden(true)) {
                            Text("Create now")
                                .font(.custom("Roboto", size: 16))
                                .foregroundColor(.blue)
                                .underline()
                        }
                    }
                    .padding(.top, 20)

                    NavigationLink("", destination: AdminDashboardView().navigationBarBackButtonHidden(true), isActive: $isAdmin)
                    NavigationLink("", destination: SampleView().navigationBarBackButtonHidden(true), isActive: $isLoginSuccessful)
                }
                .padding()
                .frame(maxHeight: .infinity, alignment: .top)
            }
        }
        .onAppear { showTabBar = false }
        .onDisappear { showTabBar = true }
        .alert(isPresented: $showAlert) {  // ✅ Show alert when there's an error
            Alert(
                title: Text("Login Failed"),
                message: Text(errorMessage ?? "Something went wrong."),
                dismissButton: .default(Text("OK"))
            )
        }
    }

    // Login API Call
    func loginUser() {
        guard !email.isEmpty, !password.isEmpty else {
            errorMessage = "Please enter email and password"
            showAlert = true  // ✅ Show alert
            return
        }

        isLoading = true
        errorMessage = nil

        let parameters: [String: String] = [
            "email": email,
            "password": password
        ]

        APIService.shared.sendFormDataRequest(endpoint: APIHandler.login, parameters: parameters) { result in
            DispatchQueue.main.async {
                isLoading = false
                switch result {
                case .success(let json):
                    if let status = json["status"] as? Bool, status,
                       let dataArray = json["data"] as? [[String: Any]],
                       let userData = dataArray.first {
                        
                        if let userId = userData["user_id"] as? Int {
                            UserDefaults.standard.set(userId, forKey: "user_id")
                        }

                        if let name = userData["name"] as? String {
                            UserDefaults.standard.set(name, forKey: "name")
                        }
                        if let email = userData["email"] as? String {
                            UserDefaults.standard.set(email, forKey: "email")
                        }
                        if let phoneNumber = userData["phone"] as? String {
                            UserDefaults.standard.set(phoneNumber, forKey: "phoneNumber")
                        }
                        
                        if let isAdminValue = userData["is_admin"] {
                            if let isAdminInt = isAdminValue as? Int, isAdminInt == 1 {
                                isAdmin = true
                            } else if let isAdminString = isAdminValue as? String, isAdminString == "1" {
                                isAdmin = true
                            } else {
                                isLoginSuccessful = true
                            }
                        } else {
                            isLoginSuccessful = true
                        }
                    } else {
                        errorMessage = json["message"] as? String ?? "Invalid email or password"
                        showAlert = true  // ✅ Show alert on failure
                    }
                case .failure(let error):
                    errorMessage = "Request failed: \(error.localizedDescription)"
                    showAlert = true  // ✅ Show alert on failure
                }
            }
        }
    }
}

struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        LoginView(showTabBar: .constant(true))
    }
}
