import SwiftUI

struct LocationView: View {
    let localities = ["ECR", "T Nagar", "Anna Nagar", "Poonamalle"]
    @State private var searchText = ""
    @State private var filteredLocalities: [String]
    @Binding var selectedTab: SampleView.Tab
    @Environment(\.presentationMode) var presentationMode // Dismiss view

    init(selectedTab: Binding<SampleView.Tab>) {
        _filteredLocalities = State(initialValue: ["ECR", "T Nagar", "Poonamalle", "Anna Nagar"])
        _selectedTab = selectedTab
    }

    var body: some View {
        NavigationView {
            ZStack(alignment: .top) {
                LinearGradient(gradient: Gradient(colors: [Color(red: 0.54, green: 0.74, blue: 1), .white]), startPoint: .top, endPoint: .bottom)
                    .edgesIgnoringSafeArea(.all)

                VStack(spacing: 0) {
                    HStack {
                        Button(action: {
                            selectedTab = .search
                            presentationMode.wrappedValue.dismiss() // Dismiss screen
                        }) {
                            Image(systemName: "chevron.left")
                                .font(.system(size: 20, weight: .bold))
                                .foregroundColor(.black)
                                .padding(.top, 2.0)
                                .padding(.leading, 8.0)
                        }

                        Text("BookMyHall")
                            .font(.headline)
                            .fontWeight(.bold)

                        Spacer()

                        VStack {
                            Image("locationIcon")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 20, height: 20)

                            Text("Chennai")
                                .font(Font.custom("Roboto", size: 12))
                                .foregroundColor(.black)
                        }
                        .padding(.trailing, 20)
                    }
                    .padding(.horizontal)
                    .frame(height: 50)
                    .background(Color.white)
                    .zIndex(1)

                    VStack(spacing: 20) {
                        TextField("Search here", text: $searchText)
                            .padding()
                            .background(RoundedRectangle(cornerRadius: 20).fill(Color.white))
//                            .overlay(
//                                HStack {
//                                Image(systemName: "magnifyingglass").padding(.leading).foregroundColor(.blue)
//                            }, alignment: .leading)
                            .padding(.leading)
                            .onChange(of: searchText) { newValue in
                                filteredLocalities = newValue.isEmpty ? localities :
                                    localities.filter { $0.lowercased().contains(newValue.lowercased()) }
                            }

                        Text("Localities")
                            .font(.headline)
                            .fontWeight(.bold)

                        Divider()
                            .frame(width: 100)
                            .background(Color.black)

                        if filteredLocalities.isEmpty {
                            Text("No results found")
                                .font(.subheadline)
                                .foregroundColor(.gray)
                                .padding(.top, 10)
                        } else {
                            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 15) {
                                ForEach(filteredLocalities, id: \.self) { locality in
                                    Text(locality)
                                        .padding()
                                        .frame(width: 160)
                                        .background(RoundedRectangle(cornerRadius: 20).fill(Color.white).shadow(radius: 3))
                                }
                            }
                            .padding()
                        }
                    }
                    .cornerRadius(30)
                    .padding()
                }
            }
            .navigationBarHidden(true)
        }
    }
}

struct LocationView_Previews: PreviewProvider {
    static var previews: some View {
        LocationView(selectedTab: .constant(.search))
    }
}
