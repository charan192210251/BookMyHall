import SwiftUI

// MARK: - Review Model
// MARK: - Review Model
struct Review: Identifiable {
    let id: Int // Use review_id as the ID
    let rating: Int
    let comment: String
    let createdAt: String // Added to show when the review was created
    let userName: String // Added to store the reviewer's name
}



// MARK: - Review Card Component

struct ReviewCard: View {
    var review: Review
    
    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            // Profile Info (default image)
            HStack(alignment: .top, spacing: 10) {
                Image(systemName: "person.circle.fill") // Default profile image
                    .resizable()
                    .frame(width: 40, height: 40)
                    .foregroundColor(Color.gray)
                    .padding(.leading, 10)
                
                VStack(alignment: .leading, spacing: 2) {
                    Text(review.userName) // Display the actual reviewer's name
                        .font(.system(size: 14, weight: .bold))
                        .foregroundColor(Color(red: 0.44, green: 0.11, blue: 0.96))
                        .padding(.top,9)
                }
                Spacer()
            }
            
            // Comment Text
            Text(review.comment)
                .font(.system(size: 16))
                .foregroundColor(.black)
                .multilineTextAlignment(.leading)
            
            // Rating
            Text("Rating: \(review.rating) ⭐️")
                .font(.system(size: 14))
                .foregroundColor(.gray)
            
            // Display createdAt
            Text("Reviewed on: \(review.createdAt)")
                .font(.system(size: 12))
                .foregroundColor(.gray)
        }
        .padding(20)
        .frame(width: UIScreen.main.bounds.width * 0.85)
        .background(Color.white)
        .cornerRadius(10)
        .shadow(color: Color.black.opacity(0.25), radius: 4, y: 4)
    }
}



// MARK: - MccReviews View
// MARK: - MccReviews View
struct MccReviews: View {
    @Environment(\.presentationMode) var presentationMode
    var selectedHall: Hall
    
    @State private var reviews: [Review] = []
    @State private var isLoading = false
    @State private var errorMessage: String?
    
    var body: some View {
        VStack(spacing: 20) {
            // Header Section with Back Button
            HStack {
                Button(action: {
                    presentationMode.wrappedValue.dismiss() // Go back
                }) {
                    Image(systemName: "chevron.left")
                        .font(.system(size: 20, weight: .medium))
                        .foregroundColor(.black)
                        .padding(.top, 36)
                        .padding(.leading, 15)
                        .fontWeight(.bold)
                }
                
                Spacer()
                
                Text("REVIEWS")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundColor(.black)
                    .padding(.top, 40)
                    .padding(.leading, -20)
                Spacer()
            }
            .padding()
            .background(Color.white)
            
            // Display Selected Hall Name
            Text(selectedHall.name)
                .font(.system(size: 20, weight: .bold))
                .foregroundColor(.black)
                .padding(.bottom, 10)
            
            // Reviews Section
            ScrollView {
                VStack(spacing: 20) {
                    if isLoading {
                        ProgressView("Loading Reviews...")
                    } else if let errorMessage = errorMessage {
                        Text(errorMessage)
                            .foregroundColor(.red)
                            .multilineTextAlignment(.center)
                            .padding()
                    } else {
                        ForEach(reviews) { review in
                            HStack {
                                Spacer() // Pushes the card to center
                                ReviewCard(review: review)
                                Spacer() // Pushes the card to center
                            }
                        }
                    }
                }
                .padding()
            }
        }
        .background(LinearGradient(gradient: Gradient(colors: [Color(red: 0.54, green: 0.74, blue: 1), .white]), startPoint: .top, endPoint: .bottom))
        .edgesIgnoringSafeArea(.top)
        .onAppear {
            fetchReviews()
        }
    }
    
    // MARK: - Fetch Reviews Function
    private func fetchReviews() {
        guard let hallID = selectedHall.id, !hallID.isEmpty else {
            errorMessage = "Hall ID is missing"
            return
        }
        
        isLoading = true
        let parameters = ["hall_id": hallID]
        
        APIService.shared.sendFormDataRequest(endpoint: APIHandler.fetchReviews, parameters: parameters) { result in
            DispatchQueue.main.async {
                isLoading = false
                switch result {
                case .success(let jsonResponse):
                    if let status = jsonResponse["status"] as? Bool, status,
                       let reviewsArray = jsonResponse["reviews"] as? [[String: Any]] {
                        self.reviews = reviewsArray.map { reviewData in
                            Review(
                                id: reviewData["review_id"] as? Int ?? 0,
                                rating: reviewData["rating"] as? Int ?? 0,
                                comment: reviewData["comment"] as? String ?? "",
                                createdAt: reviewData["created_at"] as? String ?? "",
                                userName: reviewData["user_name"] as? String ?? "Unknown" // Extracting user_name from the response
                            )
                        }
                    } else {
                        errorMessage = jsonResponse["message"] as? String ?? "Failed to load reviews."
                    }
                case .failure(let error):
                    errorMessage = error.localizedDescription
                }
            }
        }
    }

}

// MARK: - Preview
struct MccReviews_Previews: PreviewProvider {
    static var previews: some View {
        MccReviews(selectedHall: Hall(id: "1", name: "Sample Hall", rating: "4.5", imageName: "", description: "", location: "Sample Location"))
    }
}
