import SwiftUI

struct ForgotPasswordView: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var email: String = ""
    @State private var newPassword: String = ""
    @State private var showNewPassword: Bool = false
    @State private var isLoading = false
    
    @State private var showPopup = false
    @State private var popupMessage = ""
    
    var body: some View {
        NavigationView {
            ZStack {
                LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.6), .white]),
                               startPoint: .top, endPoint: .bottom)
                    .edgesIgnoringSafeArea(.all)
                
                VStack {
                    HStack {
                        Button(action: { presentationMode.wrappedValue.dismiss() }) {
                            Image(systemName: "chevron.left")
                                .font(.title2)
                                .foregroundColor(.black)
                                .fontWeight(.bold)
                        }
                        Spacer()
                    }
                    
                    Text("Forgot Password")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .padding(.top, 10)
                    
                    VStack(alignment: .leading) {
                        Text("Email")
                            .font(.headline)
                            .foregroundColor(.black)
                            .padding(.top, 20)
                        
                        TextField("Enter your email", text: $email)
                            .textContentType(.emailAddress)
                            .keyboardType(.emailAddress)
                            .padding()
                            .background(Color.gray.opacity(0.2))
                            .cornerRadius(5)
                    }
                    
                    PasswordField(title: "New Password", text: $newPassword, showPassword: $showNewPassword)
                    
                    Button(action: {
                        validateAndResetPassword()
                    }) {
                        Text("Reset Password")
                            .frame(maxWidth: .infinity)
                            .frame(height: 50)
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                            .font(.headline)
                            .shadow(radius: 5)
                    }
                    .padding(.top, 20)
                    
                    if isLoading {
                        ProgressView().padding()
                    }
                    
                    // Go Back to Login Button
                    NavigationLink(destination: LoginView(showTabBar: .constant(true)).navigationBarBackButtonHidden(true)) {
                        Text("Go to Login")
                            .frame(maxWidth: .infinity)
                            .frame(height: 50)
                            .background(Color.green)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                            .font(.headline)
                            .shadow(radius: 5)
                    }
                    .padding(.top, 10)
                    
                    Spacer()
                }
                .padding(.horizontal, 30)
            }
            .navigationBarHidden(true) // Hides default navigation bar
            .alert(isPresented: $showPopup) {
                Alert(
                    title: Text("Password Reset"),
                    message: Text(popupMessage),
                    dismissButton: .default(Text("OK"))
                )
            }
        }
    }
    
    private func validateAndResetPassword() {
        guard !email.isEmpty, !newPassword.isEmpty else {
            showPopup(message: "All fields are required")
            return
        }
        
        isLoading = true
        
        let parameters: [String: String] = [
            "email": email,
            "new_password": newPassword
        ]
        
        APIService.shared.sendFormDataRequest(endpoint: APIHandler.forgotPassword, parameters: parameters) { result in
            DispatchQueue.main.async {
                isLoading = false
                switch result {
                case .success(let response):
                    if let status = response["status"] as? Bool, status {
                        showPopup(message: "Password reset successfully!")
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                            presentationMode.wrappedValue.dismiss()
                        }
                    } else {
                        showPopup(message: response["message"] as? String ?? "Failed to reset password")
                    }
                case .failure(let error):
                    showPopup(message: error.localizedDescription)
                }
            }
        }
    }
    
    private func showPopup(message: String) {
        popupMessage = message
        showPopup = true
    }
}

struct ForgotPasswordView_Previews: PreviewProvider {
    static var previews: some View {
        ForgotPasswordView()
    }
}
