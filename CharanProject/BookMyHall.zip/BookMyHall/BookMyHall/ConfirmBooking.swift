import SwiftUI

struct ConfirmBooking: View {
    var selectedHall: Hall
    var selectedDate: Date
    var startTime: Date
    var endTime: Date
    
    @Environment(\.presentationMode) var presentationMode
    
    @State private var isLoading = false
    @State private var showAlert = false
    @State private var alertMessage = ""
    @State private var navigateToSuccess = false
    @State private var isHoveringConfirm = false
    @State private var isHoveringCancel = false

    var body: some View {
        GeometryReader { geometry in
            NavigationView {
                ZStack {
                    LinearGradient(gradient: Gradient(colors: [Color(red: 0.54, green: 0.74, blue: 1), .white]), startPoint: .top, endPoint: .bottom)
                        .edgesIgnoringSafeArea(.all)
                    
                    VStack {
                        HStack {
                            Button(action: {
                                withAnimation {
                                    presentationMode.wrappedValue.dismiss()
                                }
                            }) {
                                Image(systemName: "chevron.left")
                                    .font(.system(size: 20, weight: .medium))
                                    .foregroundColor(.black)
                                    .padding(10)
                                    .fontWeight(.bold)
                            }
                            Spacer()
                            Text(selectedHall.name)
                                .font(Font.custom("Roboto", size: 16).weight(.semibold))
                                .foregroundColor(.black)
                                .padding(.leading,-25)
                            Spacer()
                        }
                      
                        .padding(.horizontal)
                        .frame(height: 60)
                        .background(Color.white)
                        
                        
                        Spacer().frame(height: 20)
                        
                        ZStack {
                            Rectangle()
                                .foregroundColor(.clear)
                                .background(Color.gray.opacity(0.3))
                                .frame(width: geometry.size.width * 0.8, height: 200)
                                .cornerRadius(20)
                                .shadow(radius: 5)
                                .padding(.horizontal)
                                .scaleEffect(isLoading ? 1.05 : 1)
                                .animation(.easeInOut(duration: 0.3), value: isLoading)
                            
                            VStack(spacing: 10) {
                                Text("Booking Details")
                                    .font(Font.custom("Roboto", size: 18).weight(.semibold))
                                    .foregroundColor(Color.black)
                                
                                Text("Hall: \(selectedHall.name)")
                                    .font(Font.custom("Roboto", size: 18).weight(.medium))
                                    .foregroundColor(Color.black)
                                
                                Text("Date: \(formattedDate(selectedDate))")
                                    .font(Font.custom("Roboto", size: 18).weight(.medium))
                                    .foregroundColor(Color.black)
                                
                                Text("Time: \(formattedTime(startTime)) - \(formattedTime(endTime))")
                                    .font(Font.custom("Roboto", size: 18).weight(.medium))
                                    .foregroundColor(Color.black)
                            }
                        }
                        
                        Spacer()
                    }
                    
                    VStack {
                        HStack(spacing: 30) {
                            Button(action: {
                                withAnimation {
                                    saveBooking()
                                }
                            }) {
                                Text("Confirm")
                                    .font(.headline)
                                    .foregroundColor(.white)
                                    .padding()
                                    .frame(width: geometry.size.width * 0.35)
                                    .background(isHoveringConfirm ? Color.green.opacity(0.8) : Color.green)
                                    .cornerRadius(20)
                                    .shadow(radius: 10)
                                    .scaleEffect(isHoveringConfirm ? 1.1 : 1)
                                    .animation(.spring(), value: isHoveringConfirm)
                            }
                            .onHover { hovering in
                                isHoveringConfirm = hovering
                            }
                            
                            Button(action: {
                                withAnimation {
                                    presentationMode.wrappedValue.dismiss()
                                }
                            }) {
                                Text("Cancel")
                                    .font(.headline)
                                    .foregroundColor(.white)
                                    .padding()
                                    .frame(width: geometry.size.width * 0.35)
                                    .background(isHoveringCancel ? Color.red.opacity(0.8) : Color.red)
                                    .cornerRadius(20)
                                    .shadow(radius: 10)
                                    .scaleEffect(isHoveringCancel ? 1.1 : 1)
                                    .animation(.spring(), value: isHoveringCancel)
                            }
                            .onHover { hovering in
                                isHoveringCancel = hovering
                            }
                        }
                        .padding(.top, 90)
                    }
                    
                    if isLoading {
                        Color.black.opacity(0.4)
                            .edgesIgnoringSafeArea(.all)
                        
                        ProgressView("Booking...")
                            .padding(20)
                            .background(Color.white)
                            .cornerRadius(10)
                            .shadow(radius: 10)
                            .scaleEffect(1.1)
                            .transition(.opacity.combined(with: .scale))
                    }
                }
                .alert(isPresented: $showAlert) {
                    Alert(title: Text("Error"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
                }
                .background(
                    NavigationLink(destination: Congratulations(selectedTab: .constant(.home))
                        .navigationBarBackButtonHidden(true),
                        isActive: $navigateToSuccess) {
                            EmptyView()
                        }
                )
            }
        }
    }
    
    private func formattedDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.string(from: date)
    }

    private func formattedTime(_ time: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm:ss"
        return formatter.string(from: time)
    }

    private func saveBooking() {
        isLoading = true
        
        guard let hallId = selectedHall.id else { return }
        let parameters: [String: String] = [
            "hall_id": "\(hallId)",
            "user_id": "\(UserDefaults.standard.integer(forKey: "user_id"))",
            "hall_name": selectedHall.name,
            "booking_date": formattedDate(selectedDate),
            "start_time": formattedTime(startTime),
            "end_time": formattedTime(endTime)
        ]
        
        APIService.shared.sendFormDataRequest(endpoint: APIHandler.saveBooking, parameters: parameters) { result in
            DispatchQueue.main.async {
                withAnimation {
                    isLoading = false
                }
                
                switch result {
                case .success(let response):
                    if let success = response["success"] as? Bool, success {
                        withAnimation {
                            navigateToSuccess = true
                        }
                    } else if let message = response["message"] as? String {
                        alertMessage = message
                        showAlert = true
                    }
                case .failure:
                    alertMessage = "Failed to save booking. Please try again."
                    showAlert = true
                }
            }
        }
    }
}

struct ConfirmBooking_Previews: PreviewProvider {
    static var previews: some View {
        ConfirmBooking(selectedHall: Hall(name: "MCC Marriage Hall", rating: "4.6 (814 reviews)", imageName: "mccMain"), selectedDate: Date(), startTime: Date(), endTime: Date())
    }
}
