import SwiftUI

struct AdminDashboardView: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var navigateToLogin = false // Control navigation
    @State private var showLogoutAlert = false // Show logout confirmation
    
    var body: some View {
        NavigationView {
            ZStack {
                LinearGradient(gradient: Gradient(colors: [Color(red: 0.54, green: 0.74, blue: 1), .white]), startPoint: .top, endPoint: .bottom)
                    .edgesIgnoringSafeArea(.all)
                    .animation(.easeInOut, value: navigateToLogin)
                
                VStack(spacing: 20) {
                    Text("Admin Dashboard")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .padding(.top, 40)
                        .scaleEffect(navigateToLogin ? 0.95 : 1.0)
                        .animation(.spring(), value: navigateToLogin)
                    
                    VStack(spacing: 15) {
                        NavigationLink(destination: ManageHallsView().navigationBarBackButtonHidden(true)) {
                            DashboardCard(title: "Manage Halls", icon: "building.2.fill")
                        }
                        .hoverEffect(.lift)
                        
                        NavigationLink(destination: BookingRequestsView().navigationBarBackButtonHidden(true)) {
                            DashboardCard(title: "Booking Requests", icon: "doc.text.fill")
                        }
                        .hoverEffect(.lift)
                    }
                    .padding()
                    
                    Spacer()
                    
                    Button(action: {
                        showLogoutAlert = true // Show confirmation alert
                    }) {
                        Text("Logout")
                            .font(.headline)
                            .foregroundColor(.white)
                            .frame(width: 200, height: 50)
                            .background(Color.red)
                            .cornerRadius(10)
                            .shadow(radius: 5)
                            .scaleEffect(showLogoutAlert ? 0.9 : 1.0)
                            .animation(.easeInOut(duration: 0.2), value: showLogoutAlert)
                    }
                    .padding(.bottom, 40)
                    .hoverEffect(.automatic)
                    .alert(isPresented: $showLogoutAlert) {
                        Alert(
                            title: Text("Confirm Logout"),
                            message: Text("Are you sure you want to log out?"),
                            primaryButton: .destructive(Text("Logout")) {
                                navigateToLogin = true
                            },
                            secondaryButton: .cancel()
                        )
                    }
                    
                    NavigationLink(destination: LoginView(showTabBar: .constant(true)).navigationBarBackButtonHidden(true), isActive: $navigateToLogin) {
                        EmptyView()
                    }
                    .hidden()
                }
            }
        }
    }
}

struct DashboardCard: View {
    let title: String
    let icon: String
    @State private var isHovered = false
    
    var body: some View {
        HStack {
            Image(systemName: icon)
                .font(.title)
                .foregroundColor(.white)
                .frame(width: 50, height: 50)
                .rotationEffect(isHovered ? .degrees(10) : .degrees(0))
                .animation(.easeInOut(duration: 0.3), value: isHovered)
            
            Text(title)
                .font(.title2)
                .fontWeight(.medium)
                .foregroundColor(.white)
                .padding(.leading, 10)
                .scaleEffect(isHovered ? 1.1 : 1.0)
                .animation(.spring(), value: isHovered)
            
            Spacer()
        }
        .padding()
        .frame(maxWidth: .infinity)
        .background(isHovered ? Color.blue.opacity(0.8) : Color.blue)
        .cornerRadius(15)
        .shadow(radius: 5)
        .padding(.horizontal)
        .onHover { hovering in
            isHovered = hovering
        }
    }
}

struct AdminDashboardView_Previews: PreviewProvider {
    static var previews: some View {
        AdminDashboardView()
    }
}
