import SwiftUI

struct BookingsView: View {
    @Binding var selectedTab: SampleView.Tab
    @Binding var showTabBar: Bool
    @Environment(\.presentationMode) var presentationMode
    var selectedDate: Date
    @State private var userId: Int?
    @State private var navigateToReview = false
    @State private var selectedHallId: Int?
    @State private var bookings: [Booking] = []
    @State private var isLoading = false
    @State private var errorMessage: String?

    var body: some View {
        GeometryReader { geometry in
            NavigationView {
                ZStack {
                    LinearGradient(gradient: Gradient(colors: [Color(red: 0.54, green: 0.74, blue: 1), .white]),
                                   startPoint: .top, endPoint: .bottom)
                        .edgesIgnoringSafeArea(.all)
                    
                    VStack(spacing: 0) {
                        // Header
                        VStack {
                            HStack {
                                Button(action: { presentationMode.wrappedValue.dismiss() }) {
                                    Image(systemName: "chevron.left")
                                        .font(.system(size: geometry.size.width * 0.05, weight: .bold))
                                        .foregroundColor(.black)
                                        .padding(.leading, 8)
                                }
                                Spacer()
                                Text("My Bookings")
                                    .font(Font.custom("Roboto", size: geometry.size.width * 0.05).weight(.medium))
                                    .foregroundColor(.black)
                                Spacer()
                                Image(systemName: "chevron.left")
                                    .opacity(0)
                            }
                            .padding(.horizontal, 16)
                        }
                        .frame(height: geometry.size.height * 0.05)
                        .background(Color.white)
                        //.shadow(color: Color.black.opacity(0.1), radius: 4, y: 2)
                        
                        // Loading Indicator
                        if isLoading {
                            ProgressView()
                                .progressViewStyle(CircularProgressViewStyle())
                                .padding()
                        }
                        
                        // Error Message
                        if let errorMessage = errorMessage {
                            Text(errorMessage)
                                .foregroundColor(.red)
                                .padding()
                        }
                        
                        // Bookings List
                        ScrollView {
                            ForEach(bookings, id: \.bookingId) { booking in
                                VStack(alignment: .leading, spacing: 8) {
                                    HStack {
                                        Image("mainLogo")
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: geometry.size.width * 0.15, height: geometry.size.width * 0.15)
                                            .cornerRadius(15)
                                            .shadow(color: Color.black.opacity(0.2), radius: 10, y: 2)
                                        
                                        VStack(alignment: .leading, spacing: 4) {
                                            Text(booking.hallName)
                                                .font(Font.custom("Roboto", size: geometry.size.width * 0.04))
                                                .foregroundColor(Color.black.opacity(0.7))
                                            
                                            Text("Booked on \(formattedDate(for: booking.bookingDate))")
                                                .font(Font.custom("Roboto", size: geometry.size.width * 0.035))
                                                .foregroundColor(.black)
                                        }
                                        Spacer()

                                        // Three Dots Context Menu
                                        Menu {
                                            Button(role: .destructive) {
                                                deleteBooking(bookingId: booking.bookingId)
                                            } label: {
                                                Label("Delete", systemImage: "trash")
                                            }
                                        } label: {
                                            Image(systemName: "ellipsis")
                                                .font(.system(size: 20))
                                                .foregroundColor(.black)
                                        }
                                    }
                                    .padding()
                                    
                                    // Booking Status Display
                                    HStack {
                                        Spacer()
                                        Text("Status: \(booking.status)")
                                            .font(.system(size: geometry.size.width * 0.035, weight: .bold))
                                            .foregroundColor(booking.status == "confirmed" ? .green : (booking.status == "rejected" ? .red : .orange))
                                            .padding(8)
                                            .background(booking.status == "confirmed" ? Color.green.opacity(0.2) : (booking.status == "rejected" ? Color.red.opacity(0.2) : Color.orange.opacity(0.2)))
                                            .cornerRadius(8)
                                        Spacer()
                                    }
                                    .offset(y: -10)
                                    
                                    // Add Review Button (only for confirmed bookings)
                                    if booking.status == "confirmed" {
                                        Button(action: {
                                            selectedHallId = booking.hallId
                                            navigateToReview = true
                                        }) {
                                            Text("Add Review")
                                                .font(.system(size: geometry.size.width * 0.04, weight: .bold))
                                                .foregroundColor(.white)
                                                .padding()
                                                .frame(maxWidth: .infinity)
                                                .background(Color.blue)
                                                .cornerRadius(10)
                                        }
                                        .padding(.horizontal, geometry.size.width * 0.2)
                                        .padding(.bottom, 20)
                                        .padding(.top, -10)
                                    }
                                }
                                .frame(width: geometry.size.width * 0.9, height: geometry.size.height * 0.22)
                                .background(Color(red: 0.70, green: 0.90, blue: 0.96))
                                .cornerRadius(15)
                                .shadow(color: Color.black.opacity(0.2), radius: 6)
                                .padding(.top, 20)
                            }
                        }
                        
                        Spacer()
                    }
                }
                .navigationBarHidden(true)
                .onAppear {
                    showTabBar = false
                    loadUserId()
                    fetchBookings()
                }
                .background(
                    NavigationLink(
                        destination: AddReviewView(hallId: selectedHallId ?? 0, userId: userId ?? 0).navigationBarBackButtonHidden(true),
                        isActive: $navigateToReview
                    ) { EmptyView() }
                )
            }
        }
    }
    
    private func formattedDate(for dateString: String) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        if let date = formatter.date(from: dateString) {
            formatter.dateStyle = .medium
            return formatter.string(from: date)
        }
        return dateString
    }
    
    private func loadUserId() {
        if let storedUserId = UserDefaults.standard.object(forKey: "user_id") as? Int {
            userId = storedUserId
        }
    }

    private func fetchBookings() {
        guard let userId = userId else { return }
        isLoading = true
        errorMessage = nil

        APIService.shared.sendFormDataRequest(endpoint: APIHandler.fetchBookings, parameters: ["user_id": "\(userId)"]) { result in
            DispatchQueue.main.async {
                self.isLoading = false
                switch result {
                case .success(let response):
                    if let bookingsData = response["bookings"] as? [[String: Any]] {
                        self.bookings = bookingsData.compactMap { booking in
                            guard let bookingId = booking["booking_id"] as? Int,
                                  let hallId = booking["hall_id"] as? Int,
                                  let hallName = booking["hall_name"] as? String,
                                  let bookingDate = booking["booking_date"] as? String,
                                  let status = booking["status"] as? String else { return nil }
                            return Booking(bookingId: bookingId, hallId: hallId, hallName: hallName, bookingDate: bookingDate, status: status)
                        }
                    } else {
                        self.errorMessage = "No bookings found"
                    }
                case .failure(let error):
                    self.errorMessage = "Failed to fetch bookings: \(error.localizedDescription)"
                }
            }
        }
    }

    private func deleteBooking(bookingId: Int) {
        APIService.shared.sendFormDataRequest(endpoint: APIHandler.deleteBooking, parameters: ["booking_id": "\(bookingId)"]) { result in
            DispatchQueue.main.async {
                switch result {
                case .success:
                    self.bookings.removeAll { $0.bookingId == bookingId }
                case .failure(let error):
                    self.errorMessage = "Failed to delete booking: \(error.localizedDescription)"
                }
            }
        }
    }
}

// Model for Booking
struct Booking {
    var bookingId: Int
    var hallId: Int
    var hallName: String
    var bookingDate: String
    var status: String
}

// SwiftUI Preview
struct BookingsView_Previews: PreviewProvider {
    static var previews: some View {
        BookingsView(selectedTab: .constant(.home), showTabBar: .constant(false), selectedDate: Date())
    }
}
