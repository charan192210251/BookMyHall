import SwiftUI

struct MainMenuView: View {
    @Environment(\.presentationMode) var presentationMode
    @Binding var showTabBar: Bool // Binding to control tab bar visibility

    var body: some View {
        NavigationView {
            ZStack {
                // Updated Background Gradient
                LinearGradient(
                    gradient: Gradient(colors: [Color.blue.opacity(0.7), .white]),
                    startPoint: .top,
                    endPoint: .bottom
                )
                .ignoresSafeArea()

                VStack(spacing: 0) {
                    // Title Section with Close Button on Left
                    HStack {
                        Button(action: {
                            presentationMode.wrappedValue.dismiss()
                            showTabBar = true // Show tab bar when returning
                        }) {
                            Image(systemName: "xmark.circle.fill")
                                .resizable()
                                .frame(width: 30, height: 30)
                                .foregroundColor(.white)
                        }
                        .padding(.leading)

                        Spacer()

                        Text("MENU")
                            .font(Font.custom("Roboto", size: 32).weight(.bold))
                            .foregroundColor(.white)
                            .shadow(color: .black, radius: 2, x: 0, y: 2)
                            .padding(.leading, -50)  // Move heading slightly to the left

                        Spacer()
                    }
                    .padding(.top, 5)  // Reduced top padding
                    .padding(.horizontal)

                    // Reduced gap between Heading and Menu Cards
                    VStack(spacing: 15) {
                        // Navigation to ProfileView in SampleView
                        NavigationLink(destination: BookingsView(selectedTab: .constant(.home), showTabBar: .constant(true), selectedDate: Date()).navigationBarBackButtonHidden(true)) {
                            MenuCardView(title: "My Bookings", description: "Manage your bookings", icon: "ticket.fill")
                        }
                        NavigationLink(destination: MyReviewsView().navigationBarBackButtonHidden(true)){
                        MenuCardView(title: "My Reviews", description: "Manage your reviews", icon: "book.fill")
                    }
                        NavigationLink(destination: ContactUsView().navigationBarBackButtonHidden(true)){
                        MenuCardView(title: "Contact Us", description: "Get in touch with us", icon: "message.fill")
                    }
                        
                    }
                    .padding(.top, 15)

                    Spacer()
                }
                .padding()
            }
        }
        .onAppear {
            showTabBar = false // Hide tab bar when MainMenuView appears
        }
    }
}

struct MenuCardView: View {
    var title: String
    var description: String
    var icon: String

    var body: some View {
        ZStack {
            // Background Color and Card Shadow
            RoundedRectangle(cornerRadius: 20)
                .fill(Color.white)
                .shadow(radius: 10)
                .frame(height: 100)

            HStack {
                Image(systemName: icon)
                    .foregroundColor(.blue)
                    .font(.system(size: 40))
                    .padding()

                VStack(alignment: .leading) {
                    Text(title)
                        .font(Font.custom("Roboto", size: 20).weight(.bold))
                        .foregroundColor(.black)

                    Text(description)
                        .font(Font.custom("Roboto", size: 14))
                        .foregroundColor(.gray)
                }
                .padding(.leading, 10)

                Spacer()

                Image(systemName: "chevron.right")
                    .foregroundColor(.gray)
                    .padding()
            }
            .padding(.horizontal)
        }
    }
}

struct MainMenuView_Previews: PreviewProvider {
    static var previews: some View {
        MainMenuView(showTabBar: .constant(true))
    }
}
