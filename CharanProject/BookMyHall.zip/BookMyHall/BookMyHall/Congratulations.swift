import SwiftUI

struct Congratulations: View {
    @Environment(\.presentationMode) var presentationMode
    @Binding var selectedTab: SampleView.Tab // Binding to update the tab selection

    var body: some View {
        NavigationView {
            ZStack {
                Text("BookMyHall")
                    .font(Font.custom("Roboto", size: 18).weight(.bold))
                    .foregroundColor(.black)
                    .offset(y: -386.5)

                Text("Congratulations !")
                    .font(Font.custom("Roboto", size: 25).weight(.semibold))
                    .foregroundColor(.black)
                    .offset(y: -285)

                Image("tickLogo") // Use Image directly
                    .resizable()
                    .frame(width: 150, height: 150)
                    .offset(y: -157.5)

                Rectangle()
                    .foregroundColor(.clear)
                    .frame(width: 372, height: 72)
                    .background(Color(red: 0.88, green: 0.93, blue: 0.98))
                    .cornerRadius(10)
                   // .offset(y: 12.5)
                    .shadow(color: Color.black.opacity(0.25), radius: 4, y: 4)
                
                    .overlay(Text("Your booking has been successfully confirmed !")
                        .font(Font.custom("Roboto", size: 16).weight(.medium))
                        .foregroundColor(.black)
                        //.offset(y: 12)
                        .padding(.horizontal))
                    

                NavigationLink(destination: SampleView().navigationBarBackButtonHidden(true)){
                    ZStack {
                        Rectangle()
                            .frame(width: 250, height: 50)
                            .foregroundColor(.clear)
                            .background(Color.green)
                            .cornerRadius(25)

                        Text("Go Back to Home")
                            .font(.headline)
                            .foregroundColor(.black)
                    }
                    .padding(.top, 300)
                    .shadow(color: Color.black.opacity(0.25), radius: 4, y: 4)
                    .contentShape(Rectangle()) // Ensure the button is tappable
                }
                .buttonStyle(PlainButtonStyle())
            }
            .frame(width: 412, height: 917)
            .background(
                LinearGradient(gradient: Gradient(colors: [Color(red: 0.54, green: 0.74, blue: 1), .white]), startPoint: .top, endPoint: .bottom)
            )
            .cornerRadius(30)
        }
    }
}

// **Preview**
struct Congratulations_Previews: PreviewProvider {
    static var previews: some View {
        Congratulations(selectedTab: .constant(.home))
    }
}
