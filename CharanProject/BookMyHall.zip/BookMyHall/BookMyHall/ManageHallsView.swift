import SwiftUI

struct ManageHallsView: View {
    @Environment(\.presentationMode) var presentationMode

    var body: some View {
        NavigationView {
            ZStack {
                // Background Gradient
                LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.7), .white]), startPoint: .top, endPoint: .bottom)
                    .edgesIgnoringSafeArea(.all)

                VStack {
                    HStack {
                        Button(action: {
                            presentationMode.wrappedValue.dismiss()
                        }) {
                            Image(systemName: "chevron.left")
                                .font(.system(size: 20, weight: .bold))
                                .foregroundColor(.black)
                                .padding()
                                .fontWeight(.bold)
                            
                        }
                        .offset(x:-20,y:-20)
                        Spacer()
                    }
                    .padding(.leading)
                    .frame(maxWidth: .infinity, alignment: .leading)

                    Text("Manage Halls")
                        .font(.system(size: 34, weight: .heavy)) // Adaptive font
                        .foregroundColor(.black)
                        .padding(.bottom, 20)

                    // Buttons Stack
                    VStack(spacing: 20) {
                        NavigationLink(destination: AddHallView(halls: .constant([])).navigationBarBackButtonHidden(true)) {
                            DashboardButton(title: "Add Hall")
                        }

                        NavigationLink(destination: UpdateHallView().navigationBarBackButtonHidden(true)) {
                            DashboardButton(title: "Update Hall")
                        }

                        NavigationLink(destination: DeleteHallView().navigationBarBackButtonHidden(true)) {
                            DashboardButton(title: "Delete Hall")
                        }

                        NavigationLink(destination: ImageView().navigationBarBackButtonHidden(true)) {
                            DashboardButton(title: "Upload Images")
                        }
                    }
                    .padding(.horizontal, 20)
                    .frame(maxWidth: 500) // Limit width for better scaling

                    Spacer() // Pushes content up for better layout
                }
                .padding()
            }
        }
    }
}

// Reusable Button Component
struct DashboardButton: View {
    var title: String

    var body: some View {
        Text(title)
            .font(.title2)
            .fontWeight(.medium)
            .foregroundColor(.white)
            .frame(maxWidth: .infinity, minHeight: 50) // Ensures buttons scale properly
            .background(Color.black)
            .cornerRadius(6)
            .shadow(color: Color.gray.opacity(0.5), radius: 10, y: 4)
            .padding(.horizontal, 20)
    }
}

struct ManageHallsView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            ManageHallsView() // iPhone Preview
                .previewDevice("iPhone 15 Pro")

            ManageHallsView() // iPad Preview
                .previewDevice("iPad Pro (12.9-inch)")
        }
    }
}
