import SwiftUI

struct SignupView: View {
    @State private var name: String = ""
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var phoneNumber: String = ""
    
    @State private var isSignupSuccessful = false
    @State private var errorMessage: String?
    @State private var isLoading = false
    @State private var showAlert = false
    
    @State private var isPasswordVisible = false // Toggle state for password visibility

    var body: some View {
        NavigationView {
            ZStack {
                LinearGradient(
                    gradient: Gradient(colors: [Color.blue.opacity(0.7), .white]),
                    startPoint: .top,
                    endPoint: .bottom
                )
                .edgesIgnoringSafeArea(.all)

                ScrollView {
                    VStack(spacing: 20) {
                        Image("mainLogo")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 100, height: 100)
                            .shadow(color: Color.gray.opacity(0.5), radius: 5, y: 4)

                        Image("signupLogo")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 50, height: 50)
                            .shadow(color: Color.gray.opacity(0.5), radius: 5, y: 4)

                        Text("Sign Up")
                            .font(.largeTitle)
                            .fontWeight(.heavy)
                            .foregroundColor(Color.black.opacity(0.8))

                        VStack(alignment: .leading, spacing: 12) {
                            Text("Name")
                                .font(.custom("Roboto", size: 16))
                                .foregroundColor(.black)

                            CustomInputField(placeholder: "Enter your name", text: $name)

                            Text("Phone Number")
                                .font(.custom("Roboto", size: 16))
                                .foregroundColor(.black)

                            CustomInputField(placeholder: "Enter your phone number", text: $phoneNumber, keyboardType: .phonePad)

                            Text("Email")
                                .font(.custom("Roboto", size: 16))
                                .foregroundColor(.black)

                            CustomInputField(placeholder: "Enter your email", text: $email)

                            Text("Password")
                                .font(.custom("Roboto", size: 16))
                                .foregroundColor(.black)

                            CustomPasswordInput(password: $password, isPasswordVisible: $isPasswordVisible)
                        }
                        .padding(.horizontal, 25)

                        Button(action: { validateAndRegisterUser() }) {
                            Text("Sign Up")
                                .font(.custom("Roboto", size: 16))
                                .fontWeight(.medium)
                                .foregroundColor(.white)
                                .frame(width: 290, height: 45)
                                .background(Color.black)
                                .cornerRadius(6)
                                .shadow(color: Color.gray.opacity(0.5), radius: 5, y: 4)
                        }
                        .padding(.top, 20)

                        HStack {
                            Text("Already have an account? ")
                                .font(.custom("Roboto", size: 16))
                                .foregroundColor(.black)

                            NavigationLink(destination: LoginView(showTabBar: .constant(true)).navigationBarBackButtonHidden(true)) {
                                Text("Log in")
                                    .font(.custom("Roboto", size: 16))
                                    .foregroundColor(.blue)
                                    .underline()
                            }
                        }
                        .padding(.top, 20)

                        Spacer(minLength: 50)
                    }
                    .padding()
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
                }

                NavigationLink(destination: SuccessSignupView().navigationBarBackButtonHidden(true), isActive: $isSignupSuccessful) {
                    EmptyView()
                }

                // Loading Indicator
                if isLoading {
                    ProgressView()
                        .progressViewStyle(CircularProgressViewStyle())
                        .scaleEffect(2)
                        .padding()
                        .background(Color.white.opacity(0.7))
                        .cornerRadius(10)
                }
            }
            .alert(isPresented: $showAlert) {
                Alert(title: Text("Error"), message: Text(errorMessage ?? "Something went wrong"), dismissButton: .default(Text("OK")))
            }
        }
    }

    func validateAndRegisterUser() {
        guard !name.isEmpty, !email.isEmpty, !password.isEmpty, !phoneNumber.isEmpty else {
            errorMessage = "Please enter all details"
            showAlert = true
            return
        }

        registerUser()
    }

    func registerUser() {
        isLoading = true
        
        let parameters: [String: String] = [
            "name": name,
            "phone": phoneNumber,
            "email": email,
            "password": password
        ]

        APIService.shared.sendFormDataRequest(endpoint: APIHandler.register, parameters: parameters) { result in
            DispatchQueue.main.async {
                isLoading = false
                
                switch result {
                case .success(let response):
                    if let status = response["status"] as? Bool, status {
                        UserDefaults.standard.set(name, forKey: "name")
                        UserDefaults.standard.set(email, forKey: "email")
                        UserDefaults.standard.set(phoneNumber, forKey: "phoneNumber")
                        isSignupSuccessful = true
                    } else {
                        errorMessage = response["message"] as? String ?? "Something went wrong"
                        showAlert = true
                    }
                case .failure(let error):
                    errorMessage = error.localizedDescription
                    showAlert = true
                }
            }
        }
    }
}

// Custom Input Field Component
struct CustomInputField: View {
    var placeholder: String
    @Binding var text: String
    var keyboardType: UIKeyboardType = .default

    var body: some View {
        TextField(placeholder, text: $text)
            .padding()
            .frame(height: 45)
            .background(Color.white.opacity(0.8))
            .cornerRadius(6)
            .keyboardType(keyboardType)
            .shadow(color: Color.gray.opacity(0.2), radius: 4, y: 2)
    }
}

// Custom Password Input Component
struct CustomPasswordInput: View {
    @Binding var password: String
    @Binding var isPasswordVisible: Bool

    var body: some View {
        ZStack(alignment: .trailing) {
            if isPasswordVisible {
                TextField("Enter your password", text: $password)
                    .padding()
                    .frame(height: 45)
                    .background(Color.white.opacity(0.8))
                    .cornerRadius(6)
                    .shadow(color: Color.gray.opacity(0.2), radius: 4, y: 2)
            } else {
                SecureField("Enter your password", text: $password)
                    .padding()
                    .frame(height: 45)
                    .background(Color.white.opacity(0.8))
                    .cornerRadius(6)
                    .shadow(color: Color.gray.opacity(0.2), radius: 4, y: 2)
            }

            Button(action: {
                isPasswordVisible.toggle()
            }) {
                Image(systemName: isPasswordVisible ? "eye.slash.fill" : "eye.fill")
                    .foregroundColor(.gray)
                    .padding(.trailing, 12)
            }
        }
    }
}

// Preview
struct SignupView_Previews: PreviewProvider {
    static var previews: some View {
        SignupView()
            .previewDevice("iPhone 16 Pro")
    }
}
