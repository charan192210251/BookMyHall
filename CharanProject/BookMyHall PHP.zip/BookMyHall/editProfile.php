<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include('db.php');

// Check DB connection
if (!$conn) {
    die(json_encode(["status" => false, "message" => "Database connection failed"]));
}

// Ensure POST request contains required fields
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['user_id'], $_POST['name'], $_POST['phone'], $_POST['email'])) {
        echo json_encode(["status" => false, "message" => "All fields are required"]);
        exit;
    }

    $user_id = $_POST['user_id']; // Get user ID
    $name = htmlspecialchars(trim($_POST['name'])); // User's name
    $phone = htmlspecialchars(trim($_POST['phone'])); // User's phone number
    $email = htmlspecialchars(trim($_POST['email'])); // User's email

    // Validate email and phone
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(["status" => false, "message" => "Invalid email"]);
        exit;
    }
    if (!preg_match('/^\d{10}$/', $phone)) {
        echo json_encode(["status" => false, "message" => "Invalid phone number"]);
        exit;
    }

    // Update user profile query (excluding password)
    $query = "UPDATE userslogin SET name = ?, phone = ?, email = ? WHERE user_id = ?";

    // Prepare and execute the update statement
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        die(json_encode(["status" => false, "message" => "SQL Error: " . $conn->error]));
    }

    // Bind parameters and execute the query
    $stmt->bind_param('sssi', $name, $phone, $email, $user_id);
    if (!$stmt->execute()) {
        die(json_encode(["status" => false, "message" => "SQL Error: " . $stmt->error]));
    }

    // Fetch the updated user details
    $stmt = $conn->prepare("SELECT user_id, name, phone, email, is_admin FROM userslogin WHERE user_id = ?");
    $stmt->bind_param('s', $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    // Return updated user profile details
    echo json_encode([
        "status" => true,
        "message" => "Profile updated successfully",
        "data" => [
            [
                "user_id" => $user['user_id'],  // ✅ Fixed here
                "name" => $user['name'],
                "phone" => $user['phone'],
                "email" => $user['email'],
                "is_admin" => $user['is_admin']
            ]
        ]
    ]);
    exit;
} else {
    echo json_encode(["status" => false, "message" => "Invalid request method"]);
    exit;
}
?>
