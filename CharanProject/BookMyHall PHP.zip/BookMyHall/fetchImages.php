
<?php
include 'db.php';

if (isset($_GET['hall_id'])) {
    $hall_id = $_GET['hall_id'];

    $stmt = $conn->prepare("SELECT image_url FROM hall_images WHERE hall_id = ?");
    $stmt->bind_param("s", $hall_id);
    $stmt->execute();
    $result = $stmt->get_result();

    $images = [];
    while ($row = $result->fetch_assoc()) {
        $images[] = $row['image_url'];
    }

    echo json_encode(["success" => true, "images" => $images]);
} else {
    echo json_encode(["success" => false, "message" => "Hall ID is required"]);
}
?>
