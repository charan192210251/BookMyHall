<?php
include 'db.php'; // Include your database connection

header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $review_id = $_POST['review_id'] ?? '';

    if (!empty($review_id)) {
        $stmt = $conn->prepare("DELETE FROM reviews WHERE review_id = ?");
        $stmt->bind_param("i", $review_id);

        if ($stmt->execute()) {
            echo json_encode(["status" => true, "message" => "Review deleted successfully"]);
        } else {
            echo json_encode(["status" => false, "message" => "Failed to delete review"]);
        }

        $stmt->close();
    } else {
        echo json_encode(["status" => false, "message" => "Invalid request"]);
    }
} else {
    echo json_encode(["status" => false, "message" => "Invalid method"]);
}

$conn->close();
?>
