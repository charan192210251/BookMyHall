<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

// Include database connection
include 'db.php';

// Retrieve form data from request
$user_id = $_POST['user_id'] ?? '';
$first_name = $_POST['first_name'] ?? '';
$last_name = $_POST['last_name'] ?? '';
$email = $_POST['email'] ?? '';
$message = $_POST['message'] ?? '';

// Validate required fields
if (empty($user_id) || empty($first_name) || empty($last_name) || empty($email) || empty($message)) {
    echo json_encode(["status" => "error", "message" => "All fields are required"]);
    exit;
}

// Store message in the database
$stmt = $conn->prepare("INSERT INTO contact_messages (user_id, first_name, last_name, email, message) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("sssss", $user_id, $first_name, $last_name, $email, $message);

if ($stmt->execute()) {
    // Send Email to Admin
    $admin_email = "durgac991@gmail.com";  // Replace with your email
    $subject = "New Contact Us Form Submission";
    $email_body = "
        <h2>New Contact Us Submission</h2>
        <p><strong>User ID:</strong> $user_id</p>
        <p><strong>Name:</strong> $first_name $last_name</p>
        <p><strong>Email:</strong> $email</p>
        <p><strong>Message:</strong><br>$message</p>
    ";

    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8" . "\r\n";
    $headers .= "From: no-reply@example.com" . "\r\n";  // Replace with your sender email

    if (mail($admin_email, $subject, $email_body, $headers)) {
        echo json_encode(["status" => "success", "message" => "Message sent successfully"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Email sending failed"]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Database insertion failed"]);
}

// Close statement and connection
$stmt->close();
$conn->close();
?>
