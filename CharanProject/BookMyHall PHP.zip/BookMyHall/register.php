<?php
include('db.php');
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT); // Enable error reporting

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = htmlspecialchars(trim($_POST['name']));
    $phone = htmlspecialchars(trim($_POST['phone']));
    $email = htmlspecialchars(trim($_POST['email']));
    $password = htmlspecialchars(trim($_POST['password'])); // Store password as plain text ❌ (Not Secure)
    $is_admin = isset($_POST['is_admin']) ? $_POST['is_admin'] : 0; // Default to 0 if not provided

    // Validate inputs
    if (!empty($email) && !empty($password) && filter_var($email, FILTER_VALIDATE_EMAIL)) {
        if (preg_match('/^\d{10}$/', $phone)) {
            try {
                // Check if email already exists
                $emailCheckQuery = "SELECT * FROM userslogin WHERE email = ?";
                $stmt = $conn->prepare($emailCheckQuery);
                $stmt->bind_param("s", $email);
                $stmt->execute();
                $stmt->store_result();

                if ($stmt->num_rows > 0) {
                    // Email already exists, return an error
                    echo json_encode([
                        "status" => false,
                        "message" => "Email already exists",
                        "data" => []
                    ]);
                } else {
                    // Proceed with user registration
                    $query = "INSERT INTO userslogin (name, phone, email, password, is_admin) VALUES (?, ?, ?, ?, ?)";
                    $stmt = $conn->prepare($query);
                    $stmt->bind_param("ssssi", $name, $phone, $email, $password, $is_admin);

                    if ($stmt->execute()) {
                        // Get the inserted user_id
                        $user_id = $stmt->insert_id;
                        $stmt->close(); // Close statement

                        // Return success response
                        echo json_encode([
                            "status" => true,
                            "message" => "Successfully Registered",
                            "data" => [
                                [
                                    "user_id" => $user_id,  // ✅ Fixed key
                                    "name" => $name,
                                    "phone" => $phone,
                                    "email" => $email,
                                    "is_admin" => $is_admin
                                ]
                            ]
                        ]);
                    }
                }
            } catch (mysqli_sql_exception $e) {
                // Catch any other database errors
                echo json_encode([
                    "status" => false,
                    "message" => "Database error: Unable to register",
                    "error" => $e->getMessage(), // Debugging info
                    "data" => []
                ]);
            }
        } else {
            echo json_encode([
                "status" => false,
                "message" => "Invalid phone number",
                "data" => []
            ]);
        }
    } else {
        echo json_encode([
            "status" => false,
            "message" => "Invalid email or password",
            "data" => []
        ]);
    }
} else {
    echo json_encode([
        "status" => false,
        "message" => "Invalid request method",
        "data" => []
    ]);
}

?>
