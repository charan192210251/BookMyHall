<?php
// Enable error reporting for debugging (remove in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include database configuration
include 'db.php';

// Check if request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get booking ID from POST request
    $booking_id = isset($_POST['booking_id']) ? intval($_POST['booking_id']) : 0;

    // Input validation
    if ($booking_id <= 0) {
        $response = array(
            "success" => false,
            "message" => "Invalid booking ID."
        );
        echo json_encode($response);
        exit;
    }

    // Check if booking exists
    $checkQuery = "SELECT * FROM bookings WHERE booking_id = '$booking_id'";
    $checkResult = $conn->query($checkQuery);

    if ($checkResult->num_rows == 0) {
        $response = array(
            "success" => false,
            "message" => "Booking not found."
        );
        echo json_encode($response);
        exit;
    }

    // Delete booking
    $deleteQuery = "DELETE FROM bookings WHERE booking_id = '$booking_id'";
    
    if ($conn->query($deleteQuery) === TRUE) {
        $response = array(
            "success" => true,
            "message" => "Booking successfully deleted."
        );
        echo json_encode($response);
    } else {
        $response = array(
            "success" => false,
            "message" => "Error deleting booking: " . $conn->error
        );
        echo json_encode($response);
    }
} else {
    $response = array(
        "success" => false,
        "message" => "Invalid request method."
    );
    echo json_encode($response);
}

// Close the database connection
$conn->close();
?>
