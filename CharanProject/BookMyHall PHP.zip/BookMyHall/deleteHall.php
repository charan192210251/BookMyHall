<?php
include 'db.php'; // Include your database connection file

header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the hall_id from the POST request
    $hall_id = isset($_POST['hall_id']) ? $_POST['hall_id'] : null;

    // Check if hall_id is provided
    if ($hall_id === null) {
        echo json_encode([
            "status" => false,
            "message" => "Hall ID is required.",
            "data" => []
        ]);
        exit();
    }

    // Check if the hall exists before deleting
    $checkQuery = "SELECT id FROM halls WHERE id = ?";
    $stmt = mysqli_prepare($conn, $checkQuery);
    mysqli_stmt_bind_param($stmt, "i", $hall_id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);

    // If the hall does not exist, return an error
    if (mysqli_stmt_num_rows($stmt) == 0) {
        echo json_encode([
            "status" => false,
            "message" => "Hall not found.",
            "data" => []
        ]);
        exit();
    }
    mysqli_stmt_close($stmt);

    // Delete the hall from the database
    $sql = "DELETE FROM halls WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $hall_id);

    if (mysqli_stmt_execute($stmt)) {
        echo json_encode([
            "status" => true,
            "message" => "Hall deleted successfully.",
            "data" => [
                "hall_id" => $hall_id
            ]
        ]);
    } else {
        echo json_encode([
            "status" => false,
            "message" => "Error deleting hall: " . mysqli_error($conn),
            "data" => []
        ]);
    }
    mysqli_stmt_close($stmt);
}
?>
