<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Include the database connection
include('db.php');

// Get the user_id from the POST request
$user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;

// Initialize the response array
$response = ["status" => true, "message" => "", "bookings" => []];

// Check if admin or user
if ($user_id == 0) {
    // Admin request: Fetch all upcoming bookings
    $sql = "SELECT booking_id, user_id, hall_id, hall_name, booking_date, start_time, end_time, status 
            FROM bookings 
            WHERE (booking_date >= CURDATE() OR (booking_date = CURDATE() AND start_time >= CURTIME()))
            ORDER BY booking_date ASC, start_time ASC";
} else {
    // User request: Fetch past and future bookings
    $sql = "SELECT booking_id, user_id, hall_id, hall_name, booking_date, start_time, end_time, status 
            FROM bookings 
            WHERE user_id = ? 
            ORDER BY booking_date DESC, start_time ASC";  // Show past and future bookings
}

// Prepare the SQL statement
$stmt = $conn->prepare($sql);
if (!$stmt) {
    die(json_encode(["status" => false, "message" => "Query preparation failed: " . $conn->error]));
}

// Bind parameters only if user_id > 0
if ($user_id > 0) {
    $stmt->bind_param("i", $user_id);
}

// Execute the query
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $response['bookings'][] = $row;
    }
} else {
    $response["message"] = "No bookings found.";
}

// Close the statement and return the response
$stmt->close();
$conn->close();
header('Content-Type: application/json');
echo json_encode($response);

?>
