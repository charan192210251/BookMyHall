<?php
include 'db.php';

header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $sql = "SELECT * FROM halls ORDER BY id ASC"; // Fetch latest halls first
    $result = mysqli_query($conn, $sql);

    $halls = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $halls[] = $row;
    }

    echo json_encode(["status" => "success", "halls" => $halls]);
} else {
    echo json_encode(["status" => "error", "message" => "Invalid request method."]);
}
?>
