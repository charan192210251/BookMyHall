<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');
require_once 'db.php';

// Ensure the request method is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["status" => false, "message" => "Invalid request method"]);
    exit;
}

// Read form data
$hall_id = isset($_POST['hall_id']) ? intval($_POST['hall_id']) : null;
$user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : null;

// Ensure at least one parameter is provided
if (is_null($hall_id) && is_null($user_id)) {
    echo json_encode(["status" => false, "message" => "Either hall_id or user_id is required"]);
    exit;
}

// Base query
$query = "SELECT r.review_id, r.user_id, r.hall_id, r.rating, r.comment, r.created_at, 
                 u.name AS user_name, h.name AS hall_name
          FROM reviews r
          JOIN userslogin u ON r.user_id = u.user_id
          JOIN halls h ON r.hall_id = h.id  -- 🔥 FIXED: Changed `h.hall_id` to `h.id`
          WHERE 1 = 1";

$params = [];
$types = "";

// Add hall_id condition
if (!is_null($hall_id)) {
    $query .= " AND r.hall_id = ?";
    $params[] = $hall_id;
    $types .= "i";
}

// Add user_id condition
if (!is_null($user_id)) {
    $query .= " AND r.user_id = ?";
    $params[] = $user_id;
    $types .= "i";
}

// Add ordering
$query .= " ORDER BY r.created_at DESC";

// Prepare the query
$stmt = $conn->prepare($query);

// ✅ Debugging Step: Check if `prepare()` failed
if (!$stmt) {
    echo json_encode(["status" => false, "message" => "Database query preparation failed", "error" => $conn->error]);
    exit;
}

// Only bind parameters if needed
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

// Fetch reviews
$reviews = [];
while ($row = $result->fetch_assoc()) {
    $reviews[] = $row;
}

// Return JSON response
if (empty($reviews)) {
    echo json_encode(["status" => false, "message" => "No reviews found"]);
} else {
    echo json_encode(["status" => true, "reviews" => $reviews]);
}
?>
