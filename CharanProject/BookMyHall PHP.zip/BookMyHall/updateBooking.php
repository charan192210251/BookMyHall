<?php
// Include database configuration
include 'db.php';

// Check if request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $booking_id = isset($_POST['booking_id']) ? intval($_POST['booking_id']) : 0;
    $status = isset($_POST['status']) ? $_POST['status'] : '';
    $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0; // Get user_id to check for admin

    // Validate input
    if ($booking_id <= 0 || !in_array($status, ['confirmed', 'rejected', 'cancelled'])) {
        $response = array(
            "success" => false,
            "message" => "Invalid booking ID or status."
        );
        echo json_encode($response);
        exit;
    }

    // Optional: Check if the user is an admin (user_id = 0 indicates admin)
    if ($user_id !== 0) {
        $response = array(
            "success" => false,
            "message" => "Unauthorized access. Only admins can update booking status."
        );
        echo json_encode($response);
        exit;
    }

    // Prepare the SQL query to update the booking status
    $sql = "UPDATE bookings SET status = ? WHERE booking_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $status, $booking_id);

    // Execute the update query
    if ($stmt->execute()) {
        // Successfully updated the status
        $response = array(
            "success" => true,
            "message" => "Booking status updated successfully.",
            "updated_status" => $status
        );
    } else {
        // Error updating the booking status
        $response = array(
            "success" => false,
            "message" => "Error updating booking status."
        );
    }

    // Close the statement
    $stmt->close();

    // Return the response as JSON
    echo json_encode($response);
} else {
    // Invalid request method
    $response = array(
        "success" => false,
        "message" => "Invalid request method."
    );
    echo json_encode($response);
}

// Close the database connection
$conn->close();
?>
