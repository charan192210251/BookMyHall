<?php
header('Content-Type: application/json');
require_once 'db.php'; // Database connection

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get input values
    $hall_id = isset($_POST['hall_id']) ? intval($_POST['hall_id']) : null;
    $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : null;
    $rating = isset($_POST['rating']) ? intval($_POST['rating']) : null;
    $comment = isset($_POST['comment']) ? trim($_POST['comment']) : null;

    // Validate input
    if (!$hall_id || !$user_id || !$rating || !$comment) {
        echo json_encode(["status" => false, "message" => "All fields are required"]);
        exit;
    }

    if ($rating < 1 || $rating > 5) {
        echo json_encode(["status" => false, "message" => "Rating must be between 1 and 5"]);
        exit;
    }

    // Check if hall_id exists
    $hallQuery = "SELECT name FROM halls WHERE id = ?";
    $stmt = $conn->prepare($hallQuery);
    $stmt->bind_param("i", $hall_id);
    $stmt->execute();
    $hallResult = $stmt->get_result();

    if ($hallResult->num_rows === 0) {
        echo json_encode(["status" => false, "message" => "Invalid hall_id"]);
        exit;
    }

    $hallData = $hallResult->fetch_assoc();
    $hall_name = $hallData['name'];

    // Check if a review already exists by this user for this hall
    $checkReviewQuery = "SELECT review_id, rating, comment FROM reviews WHERE hall_id = ? AND user_id = ?";
    $stmt = $conn->prepare($checkReviewQuery);
    $stmt->bind_param("ii", $hall_id, $user_id);
    $stmt->execute();
    $reviewResult = $stmt->get_result();

    if ($reviewResult->num_rows > 0) {
        // Review exists, check if update is needed
        $reviewData = $reviewResult->fetch_assoc();
        $existing_review_id = $reviewData['review_id'];
        $existing_rating = $reviewData['rating'];
        $existing_comment = $reviewData['comment'];

        if ($existing_rating == $rating && $existing_comment == $comment) {
            // If both rating and comment are the same, do nothing
            echo json_encode(["status" => false, "message" => "Review already added"]);
            exit;
        } elseif ($existing_rating == $rating && $existing_comment != $comment) {
            // Update only the comment
            $updateQuery = "UPDATE reviews SET comment = ? WHERE review_id = ?";
            $stmt = $conn->prepare($updateQuery);
            $stmt->bind_param("si", $comment, $existing_review_id);
            $stmt->execute();
        } elseif ($existing_rating != $rating && $existing_comment == $comment) {
            // Update only the rating
            $updateQuery = "UPDATE reviews SET rating = ? WHERE review_id = ?";
            $stmt = $conn->prepare($updateQuery);
            $stmt->bind_param("ii", $rating, $existing_review_id);
            $stmt->execute();
        } else {
            // Update both rating and comment
            $updateQuery = "UPDATE reviews SET rating = ?, comment = ? WHERE review_id = ?";
            $stmt = $conn->prepare($updateQuery);
            $stmt->bind_param("isi", $rating, $comment, $existing_review_id);
            $stmt->execute();
        }

        echo json_encode([
            "status" => true,
            "message" => "Review updated successfully",
            "data" => [
                [
                "review_id" => $existing_review_id,
                "user_id" => $user_id,
                "hall_id" => $hall_id,
                "hall_name" => $hall_name,
                "rating" => $rating,
                "comment" => $comment,
                "created_at" => date("Y-m-d H:i:s")
            ]
        ]
        ]);
        exit;
    }

    // Insert new review
    $insertQuery = "INSERT INTO reviews (hall_id, user_id, rating, comment) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($insertQuery);
    $stmt->bind_param("iiis", $hall_id, $user_id, $rating, $comment);

    if ($stmt->execute()) {
        echo json_encode([
            "status" => true,
            "message" => "Review successfully added",
            "data" => [
                [
                "review_id" => $conn->insert_id,
                "user_id" => $user_id,
                "hall_id" => $hall_id,
                "hall_name" => $hall_name,  // Fetch hall name after querying
                "rating" => $rating,
                "comment" => $comment,
                "created_at" => date("Y-m-d H:i:s")
            ]
            ]
        ]);
    } else {
        echo json_encode(["status" => false, "message" => "Error adding review"]);
    }
}
?>
