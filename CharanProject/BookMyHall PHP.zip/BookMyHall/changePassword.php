<?php
include('db.php'); // Ensure db.php has your database connection

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if required fields are present
    if (!isset($_POST['user_id'], $_POST['old_password'], $_POST['new_password'])) {
        echo json_encode(["status" => false, "message" => "Missing required fields"]);
        exit;
    }

    // Retrieve input values
    $user_id = trim($_POST['user_id']);
    $old_password = trim($_POST['old_password']);
    $new_password = trim($_POST['new_password']);

    // Validate input
    if (empty($user_id) || empty($old_password) || empty($new_password)) {
        echo json_encode(["status" => false, "message" => "Fields cannot be empty"]);
        exit;
    }

    // Check if user exists
    $query = "SELECT password FROM userslogin WHERE user_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows == 0) {
        echo json_encode(["status" => false, "message" => "User ID not found"]);
        exit;
    }

    // Fetch the old password from the database
    $stmt->bind_result($db_password);
    $stmt->fetch();

    // Check if the old password matches
    if ($old_password !== $db_password) {
        echo json_encode(["status" => false, "message" => "Old password is incorrect"]);
        exit;
    }

    // Update password in database
    $updateQuery = "UPDATE userslogin SET password = ? WHERE user_id = ?";
    $updateStmt = $conn->prepare($updateQuery);
    $updateStmt->bind_param("si", $new_password, $user_id);

    if ($updateStmt->execute()) {
        echo json_encode(["status" => true, "message" => "Password updated successfully"]);
    } else {
        echo json_encode(["status" => false, "message" => "Failed to update password"]);
    }

    // Close statements
    $stmt->close();
    $updateStmt->close();
    $conn->close();
} else {
    echo json_encode(["status" => false, "message" => "Invalid request method"]);
}
?>
