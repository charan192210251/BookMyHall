<?php
include('db.php');


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve the user_id from the form-data
    $user_id = isset($_POST['user_id']) ? htmlspecialchars(trim($_POST['user_id'])) : null;


    // Validate the user_id
    if (!empty($user_id) && is_numeric($user_id)) {
        $query = "SELECT user_id, name, phone, email FROM userslogin WHERE user_id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $user_id);


        if ($stmt->execute()) {
            $result = $stmt->get_result();
            if ($result->num_rows > 0) {
                $user = $result->fetch_assoc();
                echo json_encode([
                    "status" => true,
                    "message" => "Profile fetched successfully",
                    "data" => [
                        [
                            "id" => $user['user_id'],
                            "name" => $user['name'],
                            "phone" => $user['phone'],
                            "email" => $user['email']
                        ]
                    ]
                ]);
            } else {
                echo json_encode([
                    "status" => false,
                    "message" => "User not found",
                    "data" => []
                ]);
            }
        } else {
            echo json_encode([
                "status" => false,
                "message" => "Database error: Unable to fetch profile",
                "data" => []
            ]);
        }
    } else {
        echo json_encode([
            "status" => false,
            "message" => "Invalid user ID",
            "data" => []
        ]);
    }
} else {
    echo json_encode([
        "status" => false,
        "message" => "Invalid request method",
        "data" => []
    ]);
}
?>
