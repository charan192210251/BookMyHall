<?php
include('db.php');
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT); // Enable error reporting

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        $query = "SELECT user_id, name, phone, email, is_admin FROM userslogin"; // Excluding password for security
        $stmt = $conn->prepare($query);
        $stmt->execute();
        $result = $stmt->get_result();

        $users = [];
        while ($row = $result->fetch_assoc()) {
            $users[] = $row;
        }

        echo json_encode([
            "status" => true,
            "message" => "Users fetched successfully",
            "data" => $users
        ]);
    } catch (mysqli_sql_exception $e) {
        echo json_encode([
            "status" => false,
            "message" => "Database error: Unable to fetch users",
            "error" => $e->getMessage(), // Debugging info
            "data" => []
        ]);
    }
} else {
    echo json_encode([
        "status" => false,
        "message" => "Invalid request method",
        "data" => []
    ]);
}
?>
