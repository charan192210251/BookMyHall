<?php
include 'db.php'; // Include your database connection file

header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $hall_id = $_POST['hall_id'];
    $name = $_POST['name'];
    $rating = $_POST['rating'];
    $imageName = $_POST['imageName'];
    $description = $_POST['description'];
    $location = $_POST['location'];
    $capacity = $_POST['capacity'];
    $facility = $_POST['facility'];
    $services = $_POST['services'];
    $availability = isset($_POST['availability']) ? $_POST['availability'] : 'yes'; // Default to 'yes'

    if (empty($hall_id) || empty($name) || empty($rating) || empty($imageName) || empty($description) || empty($location) || empty($capacity) || empty($facility) || empty($services)) {
        echo json_encode([
            "status" => false,
            "message" => "All fields are required.",
            "data" => []
        ]);
        exit();
    }

    // Check if the hall exists by ID
    $checkQuery = "SELECT id FROM halls WHERE id = ?";
    $stmt = mysqli_prepare($conn, $checkQuery);
    mysqli_stmt_bind_param($stmt, "i", $hall_id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);

    if (mysqli_stmt_num_rows($stmt) == 0) {
        echo json_encode([
            "status" => false,
            "message" => "Hall not found.",
            "data" => []
        ]);
        exit();
    }
    mysqli_stmt_close($stmt);

    // Update hall details
    $sql = "UPDATE halls SET name = ?, rating = ?, imageName = ?, description = ?, location = ?, capacity = ?, facility = ?, services = ?, availability = ? WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "sssssssssi", $name, $rating, $imageName, $description, $location, $capacity, $facility, $services, $availability, $hall_id);

    if (mysqli_stmt_execute($stmt)) {
        echo json_encode([
            "status" => true,
            "message" => "Hall updated successfully.",
            "data" => [
                [
                    "id" => $hall_id,
                    "name" => $name,
                    "rating" => $rating,
                    "imageName" => $imageName,
                    "description" => $description,
                    "location" => $location,
                    "capacity" => $capacity,
                    "facility" => $facility,
                    "services" => $services,
                    "availability" => $availability
                ]
            ]
        ]);
    } else {
        echo json_encode([
            "status" => false,
            "message" => "Error updating hall: " . mysqli_error($conn),
            "data" => []
        ]);
    }
    mysqli_stmt_close($stmt);
}
?>
