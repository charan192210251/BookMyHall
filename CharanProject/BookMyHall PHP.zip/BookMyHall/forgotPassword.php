<?php
include('db.php'); // Ensure db.php has your database connection

if (!$conn) {
    die(json_encode(["status" => false, "message" => "Database connection failed"]));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check required fields
    if (!isset($_POST['email'], $_POST['new_password'])) {
        echo json_encode(["status" => false, "message" => "Missing required fields"]);
        exit;
    }

    // Retrieve input values
    $email = trim($_POST['email']);
    $new_password = trim($_POST['new_password']);

    if (empty($email) || empty($new_password)) {
        echo json_encode(["status" => false, "message" => "Fields cannot be empty"]);
        exit;
    }

    // Check if user exists
    $query = "SELECT user_id FROM userslogin WHERE email = ?";
    $stmt = $conn->prepare($query);

    if (!$stmt) {
        die(json_encode(["status" => false, "message" => "SQL Error: " . $conn->error]));
    }

    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows == 0) {
        echo json_encode(["status" => false, "message" => "Email not found"]);
        exit;
    }

    // Fetch the user ID
    $stmt->bind_result($user_id);
    $stmt->fetch();

    // Update password in the database
    $updateQuery = "UPDATE userslogin SET password = ? WHERE user_id = ?";
    $updateStmt = $conn->prepare($updateQuery);

    if (!$updateStmt) {
        die(json_encode(["status" => false, "message" => "SQL Error: " . $conn->error]));
    }

    $updateStmt->bind_param("si", $new_password, $user_id);

    if ($updateStmt->execute()) {
        echo json_encode(["status" => true, "message" => "Password updated successfully"]);
    } else {
        echo json_encode(["status" => false, "message" => "Failed to update password"]);
    }

    // Close statements
    $stmt->close();
    $updateStmt->close();
    $conn->close();
} else {
    echo json_encode(["status" => false, "message" => "Invalid request method"]);
}
?>
