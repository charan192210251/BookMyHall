<?php
// Enable error reporting for debugging (remove in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include database configuration
include 'db.php';

// Check if request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
    $hall_id = isset($_POST['hall_id']) ? intval($_POST['hall_id']) : 0;
    $hall_name = isset($_POST['hall_name']) ? $conn->real_escape_string($_POST['hall_name']) : '';
    $booking_date = isset($_POST['booking_date']) ? $conn->real_escape_string($_POST['booking_date']) : '';
    $start_time = isset($_POST['start_time']) ? $conn->real_escape_string($_POST['start_time']) : '';
    $end_time = isset($_POST['end_time']) ? $conn->real_escape_string($_POST['end_time']) : '';
    $status = 'pending'; // Default status is 'pending'

    // Input validation
    if ($user_id <= 0 || $hall_id <= 0 || empty($hall_name) || empty($booking_date) || empty($start_time) || empty($end_time)) {
        $response = array(
            "success" => false,
            "message" => "All fields are required."
        );
        echo json_encode($response);
        exit;
    }

    // Check if the same user has already booked this hall on the same date
    $checkUserBookingQuery = "SELECT * FROM bookings 
                              WHERE user_id = '$user_id' 
                              AND hall_name = '$hall_name' 
                              AND booking_date = '$booking_date'";
    
    $userBookingResult = $conn->query($checkUserBookingQuery);

    if ($userBookingResult->num_rows > 0) {
        $response = array(
            "success" => false,
            "message" => "You have already booked this hall on the selected date."
        );
        echo json_encode($response);
        exit;
    }

    // Check for overlapping bookings for the same hall and date
    $checkOverlapQuery = "SELECT * FROM bookings 
                          WHERE hall_name = '$hall_name' 
                          AND booking_date = '$booking_date' 
                          AND (
                              (start_time < '$end_time' AND end_time > '$start_time')
                          )";

    $overlapResult = $conn->query($checkOverlapQuery);

    if ($overlapResult->num_rows > 0) {
        $response = array(
            "success" => false,
            "message" => "This hall is already booked for the selected date and time."
        );
        echo json_encode($response);
        exit;
    }

    // Insert booking into database
    $sql = "INSERT INTO bookings (user_id, hall_id, hall_name, booking_date, start_time, end_time, status) 
            VALUES ('$user_id', '$hall_id', '$hall_name', '$booking_date', '$start_time', '$end_time', '$status')";

    if ($conn->query($sql) === TRUE) {
        $booking_id = $conn->insert_id;

        // Fetch the newly inserted booking details
        $query = "SELECT * FROM bookings WHERE booking_id = '$booking_id' LIMIT 1";
        $result = $conn->query($query);

        if ($result->num_rows > 0) {
            $booking = $result->fetch_assoc();

            $response = array(
                "success" => true,
                "message" => "Booking successfully saved. Waiting for admin approval.",
                "booking_details" => array(
                    array(
                        "booking_id" => $booking['booking_id'],
                        "user_id" => $booking['user_id'],
                        "hall_id" => $booking['hall_id'],
                        "hall_name" => $booking['hall_name'],
                        "booking_date" => $booking['booking_date'],
                        "start_time" => $booking['start_time'],
                        "end_time" => $booking['end_time'],
                        "status" => $booking['status']
                    )
                )
            );
            echo json_encode($response);
        } else {
            $response = array(
                "success" => false,
                "message" => "Failed to retrieve booking details."
            );
            echo json_encode($response);
        }
    } else {
        $response = array(
            "success" => false,
            "message" => "Error: " . $conn->error
        );
        echo json_encode($response);
    }
} else {
    $response = array(
        "success" => false,
        "message" => "Invalid request method."
    );
    echo json_encode($response);
}

// Close the database connection
$conn->close();
?>
