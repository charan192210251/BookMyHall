<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include your database configuration file
include('db.php');

// Get the POST data from the request
if (isset($_POST['user_id']) && isset($_POST['name']) && isset($_POST['email']) && isset($_POST['phone'])) {
    $user_id = $_POST['user_id']; // Get the user ID (from iOS)
    $name = $_POST['name']; // User's name
    $email = $_POST['email']; // User's email
    $phone = $_POST['phone']; // User's phone number (updated variable)

    // Check DB connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Create the SQL query to update the user profile (excluding password)
    $query = "UPDATE userslogin SET name = ?, email = ?, phone = ? WHERE user_id = ?";

    // Print query for debugging
    echo "Query: " . $query . "<br />";

    // Prepare the SQL statement
    $stmt = $conn->prepare($query);

    // Check if prepare failed
    if ($stmt === false) {
        die("Error preparing the query: " . $conn->error);
    }

    // Bind parameters to the SQL statement
    $stmt->bind_param('ssss', $name, $email, $phone, $user_id);

    // Execute the query
    if ($stmt->execute()) {
        // If the profile is updated successfully, fetch the updated user information (excluding password)
        $stmt = $conn->prepare("SELECT id, name, phone AS phone, email, is_admin FROM userslogin WHERE user_id = ?");
        $stmt->bind_param('s', $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        // Return the response in the desired format, including the updated details (without password)
        echo json_encode([
            "status" => true,
            "message" => "Profile updated successfully",
            "data" => [
                [
                    "id" => $user['id'],
                    "name" => $user['name'],
                    "phone" => $user['phone'],
                    "email" => $user['email'],
                    "is_admin" => $user['is_admin']
                ]
            ]
        ]);
    } else {
        echo json_encode([
            "status" => false,
            "message" => "Failed to update profile",
            "data" => []
        ]);
    }

    // Close the database connection
    $stmt->close();
    $conn->close();
} else {
    echo json_encode([
        "status" => false,
        "message" => "Missing required POST parameters",
        "data" => []
    ]);
}
?>
