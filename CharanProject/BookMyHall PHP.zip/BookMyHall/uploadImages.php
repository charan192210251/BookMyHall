<?php
include 'db.php'; // Database connection

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['hall_id'])) {
        echo json_encode(["success" => false, "message" => "hall_id is required"]);
        exit();
    }

    $hall_id = $_POST['hall_id']; // Get the hall ID

    // ✅ Create a folder for the hall if it doesn't exist
    $hallFolder = "uploads/hall_$hall_id/";
    if (!is_dir($hallFolder)) {
        mkdir($hallFolder, 0777, true); // Create directory with full permissions
    }

    if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
        echo json_encode(["success" => false, "message" => "No image uploaded or upload error"]);
        exit();
    }

    $fileName = basename($_FILES["image"]["name"]);
    $targetFilePath = $hallFolder . time() . "_" . $fileName; // Rename file with timestamp

    if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFilePath)) {
        // ✅ Insert image data into the database with hall_id
        $sql = "INSERT INTO hall_images (hall_id, image_url) VALUES ('$hall_id', '$targetFilePath')";
        if (mysqli_query($conn, $sql)) {
            echo json_encode(["success" => true, "message" => "Image uploaded successfully", "image_url" => $targetFilePath]);
        } else {
            echo json_encode(["success" => false, "message" => "Database error"]);
        }
    } else {
        echo json_encode(["success" => false, "message" => "File upload failed"]);
    }
}
?>
