<?php
include('db.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    if (!empty($email) && !empty($password) && filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $query = "SELECT user_id, name, phone, email, password, is_admin FROM userslogin WHERE email = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $email);

        if ($stmt->execute()) {
            $result = $stmt->get_result();
            if ($result->num_rows > 0) {
                $user = $result->fetch_assoc();
                
                // Directly compare plaintext passwords (Not secure, but as per your request)
                if ($password === $user['password']) {
                    $response = [
                        "status" => true,
                        "message" => "Login successful",
                        "data" => [
                            [  
                                "user_id" => $user['user_id'],  // ✅ Fixed here
                                "name" => $user['name'],
                                "phone" => $user['phone'],
                                "email" => $user['email'],
                                "is_admin" => $user['is_admin']
                            ]
                        ],
                        "role" => ($user['is_admin'] == 1) ? "admin" : "user"
                    ];
                    echo json_encode($response);
                } else {
                    echo json_encode(["status" => false, "message" => "Invalid email or password"]);
                }
            } else {
                echo json_encode(["status" => false, "message" => "User not found"]);
            }
        } else {
            echo json_encode(["status" => false, "message" => "Database error"]);
        }

        $stmt->close();
    } else {
        echo json_encode(["status" => false, "message" => "Invalid email or password"]);
    }
} else {
    echo json_encode(["status" => false, "message" => "Invalid request method"]);
}

$conn->close();
?>
